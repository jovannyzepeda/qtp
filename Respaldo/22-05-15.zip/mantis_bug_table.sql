-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-06-2015 a las 03:55:51
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `tickets`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantis_bug_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_table` (
`id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reporter_id` int(10) unsigned NOT NULL DEFAULT '0',
  `handler_id` int(10) unsigned NOT NULL DEFAULT '0',
  `duplicate_id` int(10) unsigned NOT NULL DEFAULT '0',
  `priority` smallint(6) NOT NULL DEFAULT '30',
  `severity` smallint(6) NOT NULL DEFAULT '50',
  `reproducibility` smallint(6) NOT NULL DEFAULT '10',
  `status` smallint(6) NOT NULL DEFAULT '10',
  `resolution` smallint(6) NOT NULL DEFAULT '10',
  `projection` smallint(6) NOT NULL DEFAULT '10',
  `eta` smallint(6) NOT NULL DEFAULT '10',
  `bug_text_id` int(10) unsigned NOT NULL DEFAULT '0',
  `os` varchar(32) NOT NULL DEFAULT '',
  `os_build` varchar(32) NOT NULL DEFAULT '',
  `platform` varchar(32) NOT NULL DEFAULT '',
  `version` varchar(64) NOT NULL DEFAULT '',
  `fixed_in_version` varchar(64) NOT NULL DEFAULT '',
  `build` varchar(32) NOT NULL DEFAULT '',
  `profile_id` int(10) unsigned NOT NULL DEFAULT '0',
  `view_state` smallint(6) NOT NULL DEFAULT '10',
  `summary` varchar(128) NOT NULL DEFAULT '',
  `sponsorship_total` int(11) NOT NULL DEFAULT '0',
  `sticky` tinyint(4) NOT NULL DEFAULT '0',
  `target_version` varchar(64) NOT NULL DEFAULT '',
  `category_id` int(10) unsigned NOT NULL DEFAULT '1',
  `date_submitted` int(10) unsigned NOT NULL DEFAULT '1',
  `due_date` int(10) unsigned NOT NULL DEFAULT '1',
  `last_updated` int(10) unsigned NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `mantis_bug_table`
--

INSERT INTO `mantis_bug_table` (`id`, `project_id`, `reporter_id`, `handler_id`, `duplicate_id`, `priority`, `severity`, `reproducibility`, `status`, `resolution`, `projection`, `eta`, `bug_text_id`, `os`, `os_build`, `platform`, `version`, `fixed_in_version`, `build`, `profile_id`, `view_state`, `summary`, `sponsorship_total`, `sticky`, `target_version`, `category_id`, `date_submitted`, `due_date`, `last_updated`) VALUES
(1, 1, 3, 1, 0, 40, 60, 10, 80, 20, 10, 10, 1, '', '', '', '', '', '', 0, 10, 'Problema de accesos a share point', 0, 0, '', 2, 1426617169, 1, 1426699289),
(2, 1, 3, 1, 0, 30, 50, 70, 90, 10, 10, 10, 2, '', '', '', '', '', '', 0, 10, 'Problema con Teclado', 0, 0, '', 2, 1426703619, 1, 1426782749),
(3, 1, 3, 1, 0, 40, 30, 10, 80, 20, 10, 10, 3, '', '', '', '', '', '', 0, 10, 'Configuración de impresora', 0, 0, '', 2, 1426695739, 1, 1426782549),
(4, 1, 3, 1, 0, 30, 20, 30, 80, 20, 10, 10, 4, '', '', '', '', '', '', 0, 10, 'Problema de conexion', 0, 0, '', 2, 1426796879, 1, 1426871479),
(5, 1, 3, 1, 0, 40, 10, 100, 80, 20, 10, 10, 5, '', '', '', '', '', '', 0, 10, 'Configuración de VPN', 0, 0, '', 2, 1426799839, 1, 1426869965),
(6, 1, 3, 1, 0, 30, 50, 90, 80, 20, 10, 10, 6, '', '', '', '', '', '', 0, 10, 'Problema de red', 0, 0, '', 2, 1427131385, 1, 1427214211),
(7, 1, 3, 1, 0, 60, 80, 10, 80, 20, 10, 10, 7, '', '', '', '', '', '', 0, 10, 'Falla en maquina', 0, 0, '', 2, 1427141631, 1, 1427216015),
(8, 1, 3, 1, 0, 40, 80, 10, 80, 20, 10, 10, 8, '', '', '', '', '', '', 0, 10, 'Reparacion de SO', 0, 0, '', 2, 1427153011, 1, 1427219705),
(9, 1, 3, 1, 0, 20, 10, 10, 80, 20, 10, 10, 9, '', '', '', '', '', '', 0, 10, 'Problema al ingresar al SAT por chrome', 0, 0, '', 2, 1427213105, 1, 1427236865),
(10, 1, 3, 1, 0, 30, 10, 10, 80, 20, 10, 10, 10, '', '', '', '', '', '', 0, 10, 'Problema share Point', 0, 0, '', 2, 1427223085, 1, 1427239862),
(11, 1, 3, 1, 0, 30, 10, 10, 80, 20, 10, 10, 11, '', '', '', '', '', '', 0, 10, 'Instalacion de VPN y revision Antivirus', 0, 0, '', 2, 1427230885, 1, 1427299262),
(12, 1, 3, 1, 0, 20, 20, 10, 80, 20, 10, 10, 12, '', '', '', '', '', '', 0, 10, 'equipo con fallas', 0, 0, '', 2, 1427404322, 1, 1427413942),
(13, 1, 3, 1, 0, 20, 20, 10, 90, 10, 10, 10, 13, '', '', '', '', '', '', 0, 10, 'equipo con fallas', 0, 0, '', 2, 1427475072, 1, 1427493676),
(14, 1, 3, 1, 0, 30, 50, 100, 80, 20, 10, 10, 14, '', '', '', '', '', '', 0, 10, 'Configurar host de maquina', 0, 0, '', 2, 1427825476, 1, 1427843711),
(15, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 15, '', '', '', '', '', '', 0, 10, 'configuración de host', 0, 0, '', 2, 1427911994, 1, 1427932575),
(16, 1, 3, 1, 0, 30, 50, 100, 80, 20, 10, 10, 16, '', '', '', '', '', '', 0, 10, 'configuración de maquina', 0, 0, '', 2, 1427922961, 1, 1427993176),
(17, 1, 3, 1, 0, 50, 80, 10, 80, 20, 10, 10, 17, '', '', '', '', '', '', 0, 10, 'problema en correo outlook', 0, 0, '', 2, 1428422774, 1, 1428446584),
(18, 1, 3, 1, 0, 40, 60, 10, 80, 20, 10, 10, 18, '', '', '', '', '', '', 0, 10, 'Conexión incorrecta', 0, 0, '', 2, 1428609821, 1, 1428690741),
(19, 1, 3, 1, 0, 10, 10, 100, 80, 20, 10, 10, 19, '', '', '', '', '', '', 0, 10, 'Instalacion de software en equipo', 0, 0, '', 2, 1428616946, 1, 1428695766),
(20, 1, 3, 1, 0, 60, 80, 10, 90, 10, 10, 10, 20, '', '', '', '', '', '', 0, 10, 'Problema ordenador', 0, 0, '', 2, 1429031194, 1, 1429048564),
(21, 1, 3, 1, 0, 30, 60, 10, 80, 20, 10, 10, 21, '', '', '', '', '', '', 0, 10, 'Problema de correo', 0, 0, '', 2, 1429200401, 1, 1429213561),
(22, 1, 3, 1, 0, 10, 50, 100, 80, 20, 10, 10, 22, '', '', '', '', '', '', 0, 10, 'Instalacion de software en equipo', 0, 0, '', 2, 1429298770, 1, 1429564621),
(23, 1, 3, 1, 0, 10, 50, 100, 80, 20, 10, 10, 23, '', '', '', '', '', '', 0, 10, 'Instalacion de software en equipo', 0, 0, '', 2, 1429632811, 1, 1429654411),
(24, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 24, '', '', '', '', '', '', 0, 10, 'Problema impresora', 0, 0, '', 2, 1429895581, 1, 1430161444),
(25, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 25, '', '', '', '', '', '', 0, 10, 'Reinstalacion de software', 0, 0, '', 2, 1430413496, 1, 1430430244),
(26, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 26, '', '', '', '', '', '', 0, 10, 'Configuración de impresora', 0, 0, '', 2, 1420483404, 1, 1420502267),
(27, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 27, '', '', '', '', '', '', 0, 10, 'Conexion Dispositivo movil', 0, 0, '', 2, 1420487757, 1, 1428254105),
(28, 1, 4, 1, 0, 50, 60, 70, 80, 20, 10, 10, 28, '', '', '', '', '', '', 0, 10, 'Adaptacion de oficina', 0, 0, '', 2, 1428264112, 1, 1430845462),
(29, 1, 4, 1, 0, 30, 50, 10, 80, 20, 10, 10, 29, '', '', '', '', '', '', 0, 10, 'Problema de conexion', 0, 0, '', 2, 1428272042, 1, 1430853842),
(30, 1, 4, 1, 0, 20, 10, 10, 80, 20, 10, 10, 30, '', '', '', '', '', '', 0, 10, 'Problema antivirus', 0, 0, '', 2, 1431014652, 1, 1431033862),
(31, 1, 4, 1, 0, 40, 60, 10, 80, 20, 10, 10, 31, '', '', '', '', '', '', 0, 10, 'Problema al abrio poryect', 0, 0, '', 2, 1431363792, 1, 1431382147),
(32, 1, 4, 1, 0, 10, 10, 70, 80, 20, 10, 10, 32, '', '', '', '', '', '', 0, 10, 'problema bateria', 0, 0, '', 2, 1431373384, 1, 1431539377),
(33, 1, 4, 1, 0, 30, 50, 90, 80, 20, 10, 10, 33, '', '', '', '', '', '', 0, 10, 'Problema red y bateria', 0, 0, '', 2, 1431378234, 1, 1431447067),
(34, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 34, '', '', '', '', '', '', 0, 10, 'Problema con conexion y office', 0, 0, '', 2, 1431453687, 1, 1431462087),
(35, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 35, '', '', '', '', '', '', 0, 10, 'Problema teclado', 0, 0, '', 2, 1431632484, 1, 1431637014),
(36, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 36, '', '', '', '', '', '', 0, 10, 'Problema office', 0, 0, '', 2, 1432056203, 1, 1432066803),
(37, 1, 4, 1, 0, 30, 50, 10, 80, 20, 10, 10, 37, '', '', '', '', '', '', 0, 10, 'Problema office', 0, 0, '', 2, 1432308323, 1, 1432578165),
(38, 1, 5, 1, 0, 40, 60, 10, 90, 10, 10, 10, 38, '', '', '', '', '', '', 0, 10, 'Problema en reaccion', 0, 0, '', 2, 1432331543, 1, 1432670435),
(39, 1, 6, 1, 0, 30, 50, 70, 90, 10, 10, 10, 39, '', '', '', '', '', '', 0, 10, 'Calentamiento de equipo', 0, 0, '', 2, 1432747422, 1, 1432953240),
(40, 1, 3, 1, 0, 30, 50, 30, 80, 20, 10, 10, 40, '', '', '', '', '', '', 0, 10, 'ruido en ventilador', 0, 0, '', 2, 1432929894, 1, 1433178743),
(41, 1, 3, 1, 0, 20, 50, 10, 80, 20, 10, 10, 41, '', '', '', '', '', '', 0, 10, 'Problema cable de red', 0, 0, '', 2, 1433195704, 1, 1433259956),
(42, 1, 3, 1, 0, 10, 10, 100, 80, 20, 10, 10, 42, '', '', '', '', '', '', 0, 10, 'requerimiento de cable de red', 0, 0, '', 2, 1433261046, 1, 1433282217),
(43, 1, 3, 1, 0, 30, 50, 30, 80, 20, 10, 10, 43, '', '', '', '', '', '', 0, 10, 'Problema de acceso VPN', 0, 0, '', 2, 1433442732, 1, 1433458742),
(44, 1, 3, 1, 0, 60, 50, 10, 80, 20, 10, 10, 44, '', '', '', '', '', '', 0, 10, 'Problema de conexion', 0, 0, '', 2, 1433454306, 1, 1433545140),
(45, 1, 3, 1, 0, 30, 50, 10, 50, 10, 10, 10, 45, '', '', '', '', '', '', 0, 10, 'Acceso carpeta respaldo', 0, 0, '', 2, 1433624674, 1, 1433465520);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `mantis_bug_table`
--
ALTER TABLE `mantis_bug_table`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_bug_sponsorship_total` (`sponsorship_total`), ADD KEY `idx_bug_fixed_in_version` (`fixed_in_version`), ADD KEY `idx_bug_status` (`status`), ADD KEY `idx_project` (`project_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `mantis_bug_table`
--
ALTER TABLE `mantis_bug_table`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
