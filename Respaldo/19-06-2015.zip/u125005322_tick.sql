
-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 19, 2015 at 06:47 PM
-- Server version: 5.1.66
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `u125005322_tick`
--

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bugnote_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bugnote_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bug_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reporter_id` int(10) unsigned NOT NULL DEFAULT '0',
  `bugnote_text_id` int(10) unsigned NOT NULL DEFAULT '0',
  `view_state` smallint(6) NOT NULL DEFAULT '10',
  `note_type` int(11) DEFAULT '0',
  `note_attr` varchar(250) DEFAULT '',
  `time_tracking` int(10) unsigned NOT NULL DEFAULT '0',
  `last_modified` int(10) unsigned NOT NULL DEFAULT '1',
  `date_submitted` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_bug` (`bug_id`),
  KEY `idx_last_mod` (`last_modified`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `mantis_bugnote_table`
--

INSERT INTO `mantis_bugnote_table` (`id`, `bug_id`, `reporter_id`, `bugnote_text_id`, `view_state`, `note_type`, `note_attr`, `time_tracking`, `last_modified`, `date_submitted`) VALUES
(1, 38, 1, 1, 10, 0, '', 0, 1433271120, 1433271120),
(2, 37, 1, 2, 10, 0, '', 0, 1433271375, 1433271375),
(3, 36, 1, 3, 10, 0, '', 0, 1433341927, 1433341927),
(4, 26, 1, 4, 10, 0, '', 0, 1433360534, 1433360534),
(5, 26, 1, 5, 10, 0, '', 0, 1433360565, 1433360565),
(6, 32, 1, 6, 10, 0, '', 0, 1433360847, 1433360847),
(7, 21, 1, 7, 10, 0, '', 0, 1433444101, 1433444101),
(8, 11, 1, 8, 10, 0, '', 0, 1433444990, 1433444990),
(9, 50, 1, 9, 10, 0, '', 0, 1434479666, 1434479666),
(10, 53, 1, 10, 10, 0, '', 0, 1434729380, 1434729380);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bugnote_text_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bugnote_text_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `note` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `mantis_bugnote_text_table`
--

INSERT INTO `mantis_bugnote_text_table` (`id`, `note`) VALUES
(1, 'Se genera un cambio de Ram ampliadola de 4 gb a 6 gb , con lo que la computadora al generar pruebas nuevamente responde de forma adecuada permitiendo que el usuario pueda trabajar sin problemas'),
(2, 'Se instala el corrector ortografico y se cambia el lenguaje de teclado para que detecte el lenguaje establecido'),
(3, 'Se genera cambio de licencia y se activa nuevamente'),
(4, 'Se configura el puerto e ip de impresion para que llegue sin porblemas a la red de la impresora, se procesa la cola y todos los documentos son impresos adecuadamente'),
(5, 'Se configura el puerto e ip de impresion para que llegue sin porblemas a la red de la impresora, se procesa la cola y todos los documentos son impresos adecuadamente'),
(6, 'Se analiza la bateria y se determina que esta en buen estado (para ello se dio uso de una herramienta de analisis)'),
(7, 'Se configura correo ya que tenia un puerto uncorrecto de entrada motivo por el cual solo podia enviar pero no recibir'),
(8, 'Se configura fortissl validando la conexion correcta de Andrea Cruz y el antivirus se actualiza para que tenga el usuario y clave adecuado'),
(9, 'nstalacio de SO programado para el viernes'),
(10, 'Se requiere mas tiempo del planeado ya que la informacion a respaldar es muy grande');

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_file_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_file_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bug_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `description` varchar(250) NOT NULL DEFAULT '',
  `diskfile` varchar(250) NOT NULL DEFAULT '',
  `filename` varchar(250) NOT NULL DEFAULT '',
  `folder` varchar(250) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `file_type` varchar(250) NOT NULL DEFAULT '',
  `content` longblob NOT NULL,
  `date_added` int(10) unsigned NOT NULL DEFAULT '1',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bug_file_bug_id` (`bug_id`),
  KEY `idx_diskfile` (`diskfile`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_history_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_history_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `bug_id` int(10) unsigned NOT NULL DEFAULT '0',
  `field_name` varchar(64) NOT NULL,
  `old_value` varchar(255) NOT NULL,
  `new_value` varchar(255) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `date_modified` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_bug_history_bug_id` (`bug_id`),
  KEY `idx_history_user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=410 ;

--
-- Dumping data for table `mantis_bug_history_table`
--

INSERT INTO `mantis_bug_history_table` (`id`, `user_id`, `bug_id`, `field_name`, `old_value`, `new_value`, `type`, `date_modified`) VALUES
(1, 5, 1, '', '', '', 1, 1433179969),
(2, 5, 1, 'status', '10', '50', 0, 1433179969),
(3, 5, 1, 'handler_id', '0', '1', 0, 1433179969),
(4, 3, 2, '', '', '', 1, 1433180461),
(5, 3, 2, 'status', '10', '50', 0, 1433180461),
(6, 3, 2, 'handler_id', '0', '1', 0, 1433180461),
(7, 3, 3, '', '', '', 1, 1433180613),
(8, 3, 3, 'status', '10', '50', 0, 1433180613),
(9, 3, 3, 'handler_id', '0', '1', 0, 1433180613),
(10, 3, 4, '', '', '', 1, 1433180718),
(11, 3, 4, 'status', '10', '50', 0, 1433180718),
(12, 3, 4, 'handler_id', '0', '1', 0, 1433180718),
(13, 3, 5, '', '', '', 1, 1433180811),
(14, 3, 5, 'status', '10', '50', 0, 1433180811),
(15, 3, 5, 'handler_id', '0', '1', 0, 1433180811),
(16, 3, 6, '', '', '', 1, 1433181141),
(17, 3, 6, 'status', '10', '50', 0, 1433181141),
(18, 3, 6, 'handler_id', '0', '1', 0, 1433181141),
(19, 3, 7, '', '', '', 1, 1433182551),
(20, 3, 7, 'status', '10', '50', 0, 1433182551),
(21, 3, 7, 'handler_id', '0', '1', 0, 1433182551),
(22, 3, 8, '', '', '', 1, 1433182748),
(23, 3, 8, 'status', '10', '50', 0, 1433182748),
(24, 3, 8, 'handler_id', '0', '1', 0, 1433182748),
(25, 3, 9, '', '', '', 1, 1433182879),
(26, 3, 9, 'status', '10', '50', 0, 1433182879),
(27, 3, 9, 'handler_id', '0', '1', 0, 1433182879),
(28, 3, 10, '', '', '', 1, 1433182981),
(29, 3, 10, 'status', '10', '50', 0, 1433182981),
(30, 3, 10, 'handler_id', '0', '1', 0, 1433182981),
(31, 3, 11, '', '', '', 1, 1433184448),
(32, 3, 11, 'status', '10', '50', 0, 1433184448),
(33, 3, 11, 'handler_id', '0', '1', 0, 1433184448),
(34, 3, 12, '', '', '', 1, 1433184576),
(35, 3, 12, 'status', '10', '50', 0, 1433184576),
(36, 3, 12, 'handler_id', '0', '1', 0, 1433184576),
(37, 3, 13, '', '', '', 1, 1433184619),
(38, 3, 13, 'status', '10', '50', 0, 1433184619),
(39, 3, 13, 'handler_id', '0', '1', 0, 1433184619),
(40, 3, 14, '', '', '', 1, 1433184758),
(41, 3, 14, 'status', '10', '50', 0, 1433184758),
(42, 3, 14, 'handler_id', '0', '1', 0, 1433184758),
(43, 3, 15, '', '', '', 1, 1433184879),
(44, 3, 15, 'status', '10', '50', 0, 1433184879),
(45, 3, 15, 'handler_id', '0', '1', 0, 1433184879),
(46, 3, 16, '', '', '', 1, 1433184991),
(47, 3, 16, 'status', '10', '50', 0, 1433184991),
(48, 3, 16, 'handler_id', '0', '1', 0, 1433184991),
(49, 3, 17, '', '', '', 1, 1433185158),
(50, 3, 17, 'status', '10', '50', 0, 1433185158),
(51, 3, 17, 'handler_id', '0', '1', 0, 1433185158),
(52, 3, 18, '', '', '', 1, 1433264896),
(53, 3, 18, 'status', '10', '50', 0, 1433264896),
(54, 3, 18, 'handler_id', '0', '1', 0, 1433264896),
(55, 3, 19, '', '', '', 1, 1433265577),
(56, 3, 19, 'status', '10', '50', 0, 1433265577),
(57, 3, 19, 'handler_id', '0', '1', 0, 1433265577),
(58, 3, 20, '', '', '', 1, 1433266511),
(59, 3, 20, 'status', '10', '50', 0, 1433266511),
(60, 3, 20, 'handler_id', '0', '1', 0, 1433266511),
(61, 3, 21, '', '', '', 1, 1433266636),
(62, 3, 21, 'status', '10', '50', 0, 1433266636),
(63, 3, 21, 'handler_id', '0', '1', 0, 1433266636),
(64, 3, 22, '', '', '', 1, 1433266710),
(65, 3, 22, 'status', '10', '50', 0, 1433266710),
(66, 3, 22, 'handler_id', '0', '1', 0, 1433266710),
(67, 3, 23, '', '', '', 1, 1433266780),
(68, 3, 23, 'status', '10', '50', 0, 1433266780),
(69, 3, 23, 'handler_id', '0', '1', 0, 1433266780),
(70, 3, 24, '', '', '', 1, 1433266853),
(71, 3, 24, 'status', '10', '50', 0, 1433266853),
(72, 3, 24, 'handler_id', '0', '1', 0, 1433266853),
(73, 3, 25, '', '', '', 1, 1433266913),
(74, 3, 25, 'status', '10', '50', 0, 1433266913),
(75, 3, 25, 'handler_id', '0', '1', 0, 1433266913),
(76, 3, 26, '', '', '', 1, 1433267004),
(77, 3, 26, 'status', '10', '50', 0, 1433267004),
(78, 3, 26, 'handler_id', '0', '1', 0, 1433267004),
(79, 4, 27, '', '', '', 1, 1433268451),
(80, 4, 27, 'status', '10', '50', 0, 1433268451),
(81, 4, 27, 'handler_id', '0', '1', 0, 1433268451),
(82, 4, 28, '', '', '', 1, 1433268984),
(83, 4, 28, 'status', '10', '50', 0, 1433268984),
(84, 4, 28, 'handler_id', '0', '1', 0, 1433268984),
(85, 4, 29, '', '', '', 1, 1433269575),
(86, 4, 29, 'status', '10', '50', 0, 1433269575),
(87, 4, 29, 'handler_id', '0', '1', 0, 1433269575),
(88, 4, 30, '', '', '', 1, 1433269695),
(89, 4, 30, 'status', '10', '50', 0, 1433269695),
(90, 4, 30, 'handler_id', '0', '1', 0, 1433269695),
(91, 4, 31, '', '', '', 1, 1433269762),
(92, 4, 31, 'status', '10', '50', 0, 1433269762),
(93, 4, 31, 'handler_id', '0', '1', 0, 1433269762),
(94, 4, 32, '', '', '', 1, 1433269879),
(95, 4, 32, 'status', '10', '50', 0, 1433269879),
(96, 4, 32, 'handler_id', '0', '1', 0, 1433269879),
(97, 4, 33, '', '', '', 1, 1433269941),
(98, 4, 33, 'status', '10', '50', 0, 1433269941),
(99, 4, 33, 'handler_id', '0', '1', 0, 1433269941),
(100, 4, 34, '', '', '', 1, 1433270037),
(101, 4, 34, 'status', '10', '50', 0, 1433270037),
(102, 4, 34, 'handler_id', '0', '1', 0, 1433270037),
(103, 4, 35, '', '', '', 1, 1433270154),
(104, 4, 35, 'status', '10', '50', 0, 1433270154),
(105, 4, 35, 'handler_id', '0', '1', 0, 1433270154),
(106, 4, 36, '', '', '', 1, 1433270290),
(107, 4, 36, 'status', '10', '50', 0, 1433270290),
(108, 4, 36, 'handler_id', '0', '1', 0, 1433270290),
(109, 4, 37, '', '', '', 1, 1433270415),
(110, 4, 37, 'status', '10', '50', 0, 1433270415),
(111, 4, 37, 'handler_id', '0', '1', 0, 1433270415),
(112, 5, 38, '', '', '', 1, 1433270555),
(113, 5, 38, 'status', '10', '50', 0, 1433270555),
(114, 5, 38, 'handler_id', '0', '1', 0, 1433270555),
(115, 6, 39, '', '', '', 1, 1433270654),
(116, 6, 39, 'status', '10', '50', 0, 1433270654),
(117, 6, 39, 'handler_id', '0', '1', 0, 1433270654),
(118, 1, 38, 'Duración de Resolución', '0', '3600', 0, 1433270966),
(119, 1, 38, '', '2', '', 7, 1433271034),
(120, 1, 38, '', '0000001', '', 2, 1433271120),
(121, 1, 38, 'status', '50', '90', 0, 1433271120),
(122, 1, 37, 'Duración de Resolución', '0', '1800', 0, 1433271300),
(123, 1, 37, '', '4', '', 7, 1433271300),
(124, 1, 37, '', '0000002', '', 2, 1433271375),
(125, 1, 37, 'status', '50', '90', 0, 1433271375),
(126, 1, 36, 'Duración de Resolución', '0', '300', 0, 1433341927),
(127, 1, 36, '', '0000003', '', 2, 1433341927),
(128, 1, 36, 'status', '50', '90', 0, 1433341927),
(129, 1, 35, 'Duración de Resolución', '0', '1200', 0, 1433360447),
(130, 1, 35, 'Solucion', '', 'Se actualiza controlador de teclado y se generan pruebas las cuales no presentario problemas', 0, 1433360447),
(131, 1, 35, 'status', '50', '90', 0, 1433360447),
(132, 1, 26, 'Solucion', '', '1260', 0, 1433360534),
(133, 1, 26, '', '0000004', '', 2, 1433360534),
(134, 1, 26, 'status', '50', '90', 0, 1433360534),
(135, 1, 26, 'Duración de Resolución', '0', '1260', 0, 1433360565),
(136, 1, 26, 'Solucion', '1260', 'Se configura el puerto e ip de impresion para que llegue sin porblemas a la red de la impresora, se procesa la cola y todos los documentos son impresos adecuadamente', 0, 1433360565),
(137, 1, 26, '', '0000005', '', 2, 1433360565),
(138, 1, 26, 'resolution', '10', '20', 0, 1433360565),
(139, 1, 34, 'Duración de Resolución', '0', '1500', 0, 1433360633),
(140, 1, 34, 'Solucion', '', 'Se genera cambio de licencia y se activa nuevamente, a su vez se cambia el password que estaba en mal estado', 0, 1433360633),
(141, 1, 34, 'status', '50', '90', 0, 1433360633),
(142, 1, 33, 'Duración de Resolución', '0', '1850', 0, 1433360739),
(143, 1, 33, 'Solucion', '', 'Se actualiza controlador de red y se genera una peticion para la compra de una nueva bateria', 0, 1433360739),
(144, 1, 33, 'status', '50', '90', 0, 1433360739),
(145, 1, 32, 'Duración de Resolución', '0', '900', 0, 1433360847),
(146, 1, 32, 'Solucion', '', 'Se analiza la bateria y se determina que esta en buen estado (para ello se dio uso de una herramienta de analisis)', 0, 1433360847),
(147, 1, 32, '', '0000006', '', 2, 1433360847),
(148, 1, 32, 'status', '50', '90', 0, 1433360847),
(149, 1, 31, 'Duración de Resolución', '0', '1500', 0, 1433360929),
(150, 1, 31, 'Solucion', '', 'Se instala proyecto y se activa para que tenga acceso a los documentos requeridos', 0, 1433360929),
(151, 1, 31, 'status', '50', '90', 0, 1433360929),
(152, 1, 31, 'Duración de Resolución', '1500', '1320', 0, 1433360959),
(153, 1, 31, 'resolution', '10', '20', 0, 1433360959),
(154, 1, 30, 'Duración de Resolución', '0', '540', 0, 1433361004),
(155, 1, 30, 'Solucion', '', 'El problema que se presenta a Mystie se debe a que dentro de la red de QTP02 no se puede actualizar antivirus , se sugiere cambiar de red para solucionar problema', 0, 1433361004),
(156, 1, 30, 'status', '50', '90', 0, 1433361004),
(157, 1, 29, 'Duración de Resolución', '0', '1680', 0, 1433361068),
(158, 1, 29, 'Solucion', '', 'Se actualiza controlador de tarjeta de red, se reinicia maquina y el wifi vuelve a conectar sin problemas ', 0, 1433361068),
(159, 1, 29, 'status', '50', '90', 0, 1433361068),
(160, 1, 29, 'status', '90', '80', 0, 1433361139),
(161, 1, 29, 'resolution', '10', '20', 0, 1433361139),
(162, 1, 30, 'status', '90', '80', 0, 1433361191),
(163, 1, 30, 'resolution', '10', '20', 0, 1433361191),
(164, 1, 31, 'status', '90', '80', 0, 1433361250),
(165, 1, 32, 'status', '90', '80', 0, 1433361307),
(166, 1, 32, 'resolution', '10', '20', 0, 1433361307),
(167, 1, 33, 'status', '90', '80', 0, 1433361359),
(168, 1, 33, 'resolution', '10', '20', 0, 1433361359),
(169, 1, 34, 'status', '90', '80', 0, 1433361412),
(170, 1, 34, 'resolution', '10', '20', 0, 1433361412),
(171, 1, 26, 'status', '90', '80', 0, 1433361467),
(172, 1, 35, 'status', '90', '80', 0, 1433361538),
(173, 1, 35, 'resolution', '10', '20', 0, 1433361538),
(174, 1, 36, 'Solucion', '', 'Se genera cambio de licencia y se activa nuevamente', 0, 1433361692),
(175, 1, 36, 'status', '90', '80', 0, 1433361692),
(176, 1, 36, 'resolution', '10', '20', 0, 1433361692),
(177, 1, 37, 'Solucion', '', 'Se instala el corrector ortografico y se cambia el lenguaje de teclado para que detecte el lenguaje establecido', 0, 1433361750),
(178, 1, 37, 'status', '90', '80', 0, 1433361750),
(179, 1, 37, 'resolution', '10', '20', 0, 1433361750),
(180, 1, 19, 'Duración de Resolución', '0', '3600', 0, 1433362442),
(181, 1, 19, 'Solucion', '', 'Se instala el software requerido y a su vez se configura la cuenta de correo para que funcione adecuadamente', 0, 1433362442),
(182, 1, 19, 'status', '50', '80', 0, 1433362442),
(183, 1, 19, 'resolution', '10', '20', 0, 1433362442),
(184, 1, 18, 'Duración de Resolución', '0', '3600', 0, 1433362603),
(185, 1, 18, 'Solucion', '', 'Se configura los drivers de red ethernet y lan para que evite porblemas de conexion , se realiza pruebas y funciona adecuadamente.', 0, 1433362603),
(186, 1, 18, 'status', '50', '80', 0, 1433362603),
(187, 1, 18, 'resolution', '10', '20', 0, 1433362603),
(188, 1, 17, 'Duración de Resolución', '0', '1440', 0, 1433362786),
(189, 1, 17, 'Solucion', '', 'Se genera un cambio en el puerto de acceso SMTP y POP, se generan pruebas y el correo ya puede ser tanto enviado como recibido', 0, 1433362786),
(190, 1, 17, 'status', '50', '80', 0, 1433362786),
(191, 1, 17, 'resolution', '10', '20', 0, 1433362786),
(192, 1, 28, 'Duración de Resolución', '0', '3600', 0, 1433362920),
(193, 1, 28, 'Solucion', '', 'Se modifica area de trabajo pasando un cable de red por el techo hasta la oficina , se configura telefono y deja acceso a la red.', 0, 1433362920),
(194, 1, 28, 'status', '50', '80', 0, 1433362920),
(195, 1, 28, 'resolution', '10', '20', 0, 1433362920),
(196, 1, 27, 'Duración de Resolución', '0', '120', 0, 1433363042),
(197, 1, 27, 'Solucion', '', 'Se configura el equipo para que tenga acceso a internet agregando la clave de sye01', 0, 1433363042),
(198, 1, 27, 'status', '50', '80', 0, 1433363042),
(199, 1, 27, 'resolution', '10', '20', 0, 1433363042),
(200, 1, 25, 'Duración de Resolución', '0', '125', 0, 1433443806),
(201, 1, 25, 'Solucion', '', 'Se genera el chek list retomando datos de la maquina , instalando office, team viewer, VPN , antivirus , visio y proyect.', 0, 1433443806),
(202, 1, 25, 'status', '50', '80', 0, 1433443806),
(203, 1, 25, 'resolution', '10', '20', 0, 1433443806),
(204, 1, 24, 'Duración de Resolución', '0', '265', 0, 1433443930),
(205, 1, 24, 'Solucion', '', 'Se genera una configuracion de la maquina para que esta reconozca el puerto de escaner de la impresora, se generan pruebas se escaneado y funcionan adecuadamente , sin embargo cada cierto tiempo se presentan problemas de escaner por falla en lamparas de i', 0, 1433443930),
(206, 1, 24, 'status', '50', '80', 0, 1433443930),
(207, 1, 24, 'resolution', '10', '20', 0, 1433443930),
(208, 1, 23, 'Duración de Resolución', '0', '120', 0, 1433443973),
(209, 1, 23, 'Solucion', '', 'Se instala el software requerido y a su vez se configura la cuenta de correo para que funcione adecuadamente', 0, 1433443991),
(210, 1, 23, 'status', '50', '80', 0, 1433443991),
(211, 1, 23, 'resolution', '10', '20', 0, 1433443991),
(212, 1, 21, 'Duración de Resolución', '0', '720', 0, 1433444095),
(213, 1, 21, 'Solucion', '', 'Se configura correo ya que tenia un puerto uncorrecto de entrada motivo por el cual solo podia enviar pero no recibir', 0, 1433444101),
(214, 1, 21, '', '0000007', '', 2, 1433444101),
(215, 1, 21, 'status', '50', '80', 0, 1433444101),
(216, 1, 21, 'resolution', '10', '20', 0, 1433444101),
(217, 1, 22, 'Duración de Resolución', '0', '3000', 0, 1433444184),
(218, 1, 22, 'Solucion', '', 'Se instala el software requerido para que funcione adecuadamente', 0, 1433444184),
(219, 1, 22, 'status', '50', '80', 0, 1433444184),
(220, 1, 22, 'resolution', '10', '20', 0, 1433444184),
(221, 1, 20, 'Duración de Resolución', '0', '1500', 0, 1433444258),
(222, 1, 20, 'Solucion', '', 'Se determina que la maquina de Harim esta en mal estado por lo que se genera una cambio de maquina y la otra maquina se envia a soporte para validar si hay manera de restaurarla (El disco duro ya no es capaz de arrancar , y la bios esta estropeada)', 0, 1433444258),
(223, 1, 20, 'status', '50', '90', 0, 1433444258),
(224, 1, 16, 'Duración de Resolución', '0', '3900', 0, 1433444498),
(225, 1, 16, 'Solucion', '', 'Se genera el chek list retomando datos de la maquina , instalando office, team viewer, VPN , antivirus , visio y proyect.', 0, 1433444498),
(226, 1, 16, 'status', '50', '80', 0, 1433444498),
(227, 1, 16, 'resolution', '10', '20', 0, 1433444498),
(228, 1, 15, 'Duración de Resolución', '0', '600', 0, 1433444595),
(229, 1, 15, 'Solucion', '', 'Se configuran los documentos host, network y lmhosts para agregar la resolucion de nombres a qtpsp2010', 0, 1433444595),
(230, 1, 15, 'status', '50', '80', 0, 1433444595),
(231, 1, 15, 'resolution', '10', '20', 0, 1433444595),
(232, 1, 14, 'Duración de Resolución', '0', '600', 0, 1433444709),
(233, 1, 14, 'Solucion', '', 'Se configuran los documentos host, network y lmhosts para agregar la resolucion de nombres a qtpsp2010', 0, 1433444709),
(234, 1, 14, 'status', '50', '80', 0, 1433444709),
(235, 1, 14, 'resolution', '10', '20', 0, 1433444709),
(236, 1, 12, 'Duración de Resolución', '0', '7200', 0, 1433444904),
(237, 1, 12, 'Solucion', '', 'Se actualizan controladores del sistema en general y se solicita la adquisicion de un ventilador debido a que el equipo se encuentra expuesto a mucho calor el cual suele afectar la funcionalidad del equipo', 0, 1433444904),
(238, 1, 12, 'status', '50', '80', 0, 1433444904),
(239, 1, 12, 'resolution', '10', '20', 0, 1433444904),
(240, 1, 11, 'Solucion', '', '2100', 0, 1433444990),
(241, 1, 11, '', '0000008', '', 2, 1433444990),
(242, 1, 11, 'status', '50', '80', 0, 1433444990),
(243, 1, 11, 'resolution', '10', '20', 0, 1433444990),
(244, 1, 10, 'Duración de Resolución', '0', '5700', 0, 1433445177),
(245, 1, 10, 'Solucion', '', 'Se instalan los plugins necesarios para que pueda tener el correcto acceso al sistema de share point , (Acces database engine , y .net version 4)', 0, 1433445177),
(246, 1, 10, 'status', '50', '80', 0, 1433445177),
(247, 1, 10, 'resolution', '10', '20', 0, 1433445177),
(248, 1, 13, 'Duración de Resolución', '0', '5700', 0, 1433445239),
(249, 1, 13, 'Solucion', '', 'Se actualizan controladores del sistema en general y se solicita la adquisicion de un ventilador debido a que el equipo se encuentra expuesto a mucho calor el cual suele afectar la funcionalidad del equipo', 0, 1433445239),
(250, 1, 13, 'status', '50', '90', 0, 1433445239),
(251, 1, 9, 'Duración de Resolución', '0', '1500', 0, 1433445569),
(252, 1, 9, 'Solucion', '', 'Tras un analisis se determina que el problema es generado por problemas entre chrome y java , motivo por el cual se recomienda no usar este explorador hasta que las empresas den solucion a sus problemas', 0, 1433445569),
(253, 1, 9, 'status', '50', '80', 0, 1433445569),
(254, 1, 9, 'resolution', '10', '20', 0, 1433445569),
(255, 1, 8, 'Duración de Resolución', '0', '5580', 0, 1433445683),
(256, 1, 8, 'Solucion', '', 'Se instala en la maquina el sistema operativo windows 7 profesional y se cargan componentes de trabajo', 0, 1433445683),
(257, 1, 8, 'status', '50', '80', 0, 1433445683),
(258, 1, 8, 'resolution', '10', '20', 0, 1433445683),
(259, 1, 7, 'Duración de Resolución', '0', '5880', 0, 1433445751),
(260, 1, 7, 'Solucion', '', 'Se instala en la maquina el sistema operativo windows 7 profesional y se cargan componentes de trabajo', 0, 1433445751),
(261, 1, 7, 'status', '50', '80', 0, 1433445751),
(262, 1, 7, 'resolution', '10', '20', 0, 1433445751),
(263, 1, 4, 'Duración de Resolución', '0', '180', 0, 1433445855),
(264, 1, 4, 'Solucion', '', 'Se configura el password de la red ya que no era el correcto , con ello se obtiene internet nuevamente', 0, 1433445855),
(265, 1, 4, 'status', '50', '80', 0, 1433445855),
(266, 1, 4, 'resolution', '10', '20', 0, 1433445855),
(267, 1, 1, 'Duración de Resolución', '0', '300', 0, 1433445946),
(268, 1, 1, 'Solucion', '', 'Se configura maquina para que tenga acceso a la red adecuada ya que se encontraba fuera de la red que se requiere para ingresar al share point', 0, 1433445946),
(269, 1, 1, 'status', '50', '80', 0, 1433445946),
(270, 1, 1, 'resolution', '10', '20', 0, 1433445946),
(271, 1, 2, 'Duración de Resolución', '0', '1560', 0, 1433446040),
(272, 1, 2, 'Solucion', '', 'Se actualiza computadora con driver de teclado correcto y se cambia al idioma correcto de teclado para que los simbolos funciones tambien de forma adecuada.', 0, 1433446040),
(273, 1, 2, 'status', '50', '90', 0, 1433446040),
(274, 1, 6, 'Duración de Resolución', '0', '360', 0, 1433446146),
(275, 1, 6, 'Solucion', '', 'Se actualiza el estado del password  y de la red , a su vez se reinicia controlador y con ello se vuelve a tener acceso a internet', 0, 1433446146),
(276, 1, 6, 'status', '50', '80', 0, 1433446146),
(277, 1, 6, 'resolution', '10', '20', 0, 1433446146),
(278, 1, 5, 'Duración de Resolución', '0', '1320', 0, 1433446267),
(279, 1, 5, 'Solucion', '', 'Se instala y configura fortissl para que se tenga acceso a la red de qualtop desde fuera, se valida con usuario y efectivamente cuenta con acceso a internet', 0, 1433446267),
(280, 1, 5, 'status', '50', '80', 0, 1433446267),
(281, 1, 5, 'resolution', '10', '20', 0, 1433446267),
(282, 1, 3, 'Duración de Resolución', '0', '1680', 0, 1433446363),
(283, 1, 3, 'Solucion', '', 'Se busca impresoras dentro de la red , se agrega y se configura para que sea la impresora por defecto , a su vez se instala el controlador de la misma para evitar problemas futuros', 0, 1433446363),
(284, 1, 3, 'status', '50', '80', 0, 1433446363),
(285, 1, 3, 'resolution', '10', '20', 0, 1433446363),
(286, 3, 40, '', '', '', 1, 1433463187),
(287, 3, 40, 'status', '10', '50', 0, 1433463187),
(288, 3, 40, 'handler_id', '0', '1', 0, 1433463187),
(289, 3, 41, '', '', '', 1, 1433463318),
(290, 3, 41, 'status', '10', '50', 0, 1433463318),
(291, 3, 41, 'handler_id', '0', '1', 0, 1433463318),
(292, 3, 42, '', '', '', 1, 1433463443),
(293, 3, 42, 'status', '10', '50', 0, 1433463443),
(294, 3, 42, 'handler_id', '0', '1', 0, 1433463443),
(295, 3, 43, '', '', '', 1, 1433463560),
(296, 3, 43, 'status', '10', '50', 0, 1433463560),
(297, 3, 43, 'handler_id', '0', '1', 0, 1433463560),
(298, 3, 44, '', '', '', 1, 1433463961),
(299, 3, 44, 'status', '10', '50', 0, 1433463961),
(300, 3, 44, 'handler_id', '0', '1', 0, 1433463961),
(301, 3, 45, '', '', '', 1, 1433465520),
(302, 3, 45, 'status', '10', '50', 0, 1433465520),
(303, 3, 45, 'handler_id', '0', '1', 0, 1433465520),
(304, 1, 40, 'Duración de Resolución', '0', '5100', 0, 1433465711),
(305, 1, 40, 'Solucion', 'N/a', 'Se abre la maquina y se limpia el ventilador el cual tenia una masa anaranjada y dura q interrumpia el correcto uso del ventilador', 0, 1433465711),
(306, 1, 40, 'status', '50', '80', 0, 1433465711),
(307, 1, 40, 'resolution', '10', '20', 0, 1433465711),
(308, 1, 39, 'Duración de Resolución', '0', '3600', 0, 1433465868),
(309, 1, 39, 'Poliza', 'No', 'Si', 0, 1433465868),
(310, 1, 39, 'Solucion', '', 'Se solicita compra de ventilador y se solicita configuracion en share point a administrador de sistema', 0, 1433465868),
(311, 1, 39, 'status', '50', '90', 0, 1433465868),
(312, 1, 41, 'Duración de Resolución', '0', '1920', 0, 1433466060),
(313, 1, 41, 'Solucion', 'N/a', 'se cambia el conector que se encontraba en mal estado, motivo por el cual se desconectaba y reconectaba seguidamente', 0, 1433466060),
(314, 1, 41, 'status', '50', '80', 0, 1433466060),
(315, 1, 41, 'resolution', '10', '20', 0, 1433466060),
(316, 1, 42, 'Duración de Resolución', '0', '660', 0, 1433466721),
(317, 1, 42, 'Solucion', 'N/a', 'Se habilita un cable de red para que pueda ser utilizado', 0, 1433466721),
(318, 1, 42, 'status', '50', '80', 0, 1433466721),
(319, 1, 42, 'resolution', '10', '20', 0, 1433466721),
(320, 1, 44, 'Duración de Resolución', '0', '300', 0, 1433466799),
(321, 1, 44, 'Solucion', 'N/a', 'Se genera un cambio en la conexion de la VPN para que se tenga acceso a las conexiones de qualtop', 0, 1433466799),
(322, 1, 44, 'status', '50', '80', 0, 1433466799),
(323, 1, 44, 'resolution', '10', '20', 0, 1433466799),
(324, 1, 43, 'Duración de Resolución', '0', '3890', 0, 1433466988),
(325, 1, 43, 'Solucion', 'N/a', 'Se determina que el problema se debe a una complicacion de mozilla , motivo por el cual se recomienda no usar mozilla hasta que se recupere el problema por parte del navegador ya que el erro esta en la programacion del navegador', 0, 1433466988),
(326, 1, 43, 'status', '50', '80', 0, 1433466988),
(327, 1, 43, 'resolution', '10', '20', 0, 1433466988),
(328, 3, 46, '', '', '', 1, 1434339766),
(329, 3, 46, 'status', '10', '50', 0, 1434339766),
(330, 3, 46, 'handler_id', '0', '1', 0, 1434339766),
(331, 3, 47, '', '', '', 1, 1434339857),
(332, 3, 47, 'status', '10', '50', 0, 1434339857),
(333, 3, 47, 'handler_id', '0', '1', 0, 1434339857),
(334, 3, 48, '', '', '', 1, 1434339950),
(335, 3, 48, 'status', '10', '50', 0, 1434339950),
(336, 3, 48, 'handler_id', '0', '1', 0, 1434339950),
(337, 3, 49, '', '', '', 1, 1434340049),
(338, 3, 49, 'status', '10', '50', 0, 1434340049),
(339, 3, 49, 'handler_id', '0', '1', 0, 1434340049),
(340, 4, 50, '', '', '', 1, 1434468101),
(341, 4, 50, 'status', '10', '50', 0, 1434468101),
(342, 4, 50, 'handler_id', '0', '1', 0, 1434468101),
(343, 1, 50, 'Solucion', 'N/a', 'Se reconfigura la conexion de red en el adaptador inalambrico , sin embargo se suguiere generar una resintalacion de SO lo mas pronto posible', 0, 1434479666),
(344, 1, 50, '', '0000009', '', 2, 1434479666),
(345, 1, 50, 'status', '50', '80', 0, 1434479666),
(346, 1, 50, 'resolution', '10', '20', 0, 1434479666),
(347, 1, 48, 'Fecha de compromiso', '1434258000', '1434232800', 0, 1434479721),
(348, 1, 48, 'handler_id', '1', '7', 0, 1434479721),
(349, 1, 47, 'Fecha de compromiso', '1434258000', '1434232800', 0, 1434479744),
(350, 1, 47, 'handler_id', '1', '7', 0, 1434479744),
(351, 1, 49, 'Fecha de compromiso', '1434258000', '1434232800', 0, 1434479886),
(352, 1, 49, 'Solucion', 'N/a', 'Se configura la maquina con el driver para que esta lea adecuadamente el adaptador del scanner , se valida con usuario generando el primer scanner', 0, 1434479886),
(353, 1, 49, 'status', '50', '80', 0, 1434479886),
(354, 1, 49, 'resolution', '10', '20', 0, 1434479886),
(355, 1, 46, 'Fecha de compromiso', '1434171600', '1434146400', 0, 1434479940),
(356, 1, 46, 'Solucion', 'N/a', 'Se adapta un cable de red a la zona se;alado por el usuario , se conecta cable a computadora y se valida que funcione adecauadamente', 0, 1434479940),
(357, 1, 46, 'status', '50', '80', 0, 1434479940),
(358, 1, 46, 'resolution', '10', '20', 0, 1434479940),
(359, 1, 45, 'Duración de Resolución', '0', '900', 0, 1434480072),
(360, 1, 45, 'Fecha de compromiso', '', '1434060000', 0, 1434480072),
(361, 1, 45, 'Solucion', 'N/a', 'Se modifica password y usuario para que este tenga acceso al sistema de red', 0, 1434480072),
(362, 1, 45, 'status', '50', '80', 0, 1434480072),
(363, 1, 45, 'resolution', '10', '20', 0, 1434480073),
(364, 7, 47, 'Fecha de compromiso', '1434232800', '1434171600', 0, 1434481511),
(365, 7, 47, 'Solucion', 'N/a', 'se cambia archivo a nueva localizacion y se reconfigura la maquina para que esta pueda registrar correo en el archivo con nueva direccion', 0, 1434481511),
(366, 7, 47, 'status', '50', '80', 0, 1434481511),
(367, 7, 47, 'resolution', '10', '20', 0, 1434481511),
(368, 7, 48, 'Fecha de compromiso', '1434232800', '1434171600', 0, 1434481551),
(369, 7, 48, 'Solucion', 'N/a', 'Se modifica la configuracion del programa outlook y a su vez se mueve el archivo a la nueva direccion solicitada', 0, 1434481551),
(370, 7, 48, 'status', '50', '80', 0, 1434481551),
(371, 7, 48, 'resolution', '10', '20', 0, 1434481551),
(372, 3, 51, '', '', '', 1, 1434563791),
(373, 3, 51, 'status', '10', '50', 0, 1434563791),
(374, 3, 51, 'handler_id', '0', '1', 0, 1434563791),
(375, 1, 51, 'handler_id', '1', '7', 0, 1434563917),
(376, 7, 51, 'Duración de Resolución', '0', '900', 0, 1434568194),
(377, 7, 51, 'Solucion', 'N/a', 'Se apaga y prende el controlador y se busca problemas de red con solucionador de windows', 0, 1434568194),
(378, 7, 51, 'status', '50', '80', 0, 1434568194),
(379, 7, 51, 'resolution', '10', '20', 0, 1434568194),
(380, 3, 52, '', '', '', 1, 1434641346),
(381, 3, 52, 'status', '10', '50', 0, 1434641346),
(382, 3, 52, 'handler_id', '0', '1', 0, 1434641346),
(383, 3, 53, '', '', '', 1, 1434641429),
(384, 3, 53, 'status', '10', '50', 0, 1434641429),
(385, 3, 53, 'handler_id', '0', '1', 0, 1434641429),
(386, 1, 52, 'handler_id', '1', '7', 0, 1434641504),
(387, 4, 54, '', '', '', 1, 1434642556),
(388, 4, 54, 'status', '10', '50', 0, 1434642556),
(389, 4, 54, 'handler_id', '0', '1', 0, 1434642556),
(390, 7, 52, 'Poliza', 'No', 'Si', 0, 1434642650),
(391, 7, 52, 'Solucion', 'N/a', 'Se desconecta los mouse alambricos , se reconectan y se activa la combinacion de telcas fn + block desp', 0, 1434642650),
(392, 7, 52, 'status', '50', '80', 0, 1434642650),
(393, 7, 52, 'resolution', '10', '20', 0, 1434642650),
(394, 1, 54, 'Solucion', 'N/a', 'Se configra la maquina y se explica a usuario q en caso de ocurrir presione fn + num block', 0, 1434644907),
(395, 1, 54, 'status', '50', '80', 0, 1434644907),
(396, 1, 54, 'resolution', '10', '20', 0, 1434644907),
(397, 3, 55, '', '', '', 1, 1434645311),
(398, 3, 55, 'status', '10', '50', 0, 1434645311),
(399, 3, 55, 'handler_id', '0', '1', 0, 1434645311),
(400, 1, 55, 'Solucion', 'N/a', 'se pone en densifeccion y cuarentena los virus almacenados en el sistema', 0, 1434645825),
(401, 1, 55, 'status', '50', '80', 0, 1434645825),
(402, 1, 55, 'resolution', '10', '20', 0, 1434645825),
(403, 1, 53, '', '0000010', '', 2, 1434729380),
(404, 3, 56, '', '', '', 1, 1434730633),
(405, 3, 56, 'status', '10', '50', 0, 1434730633),
(406, 3, 56, 'handler_id', '0', '1', 0, 1434730633),
(407, 1, 56, 'Solucion', 'N/a', 'se otorga un cable usb y se configura maquina para que tenga acceso a la impresora directamente', 0, 1434738484),
(408, 1, 56, 'status', '50', '80', 0, 1434738484),
(409, 1, 56, 'resolution', '10', '20', 0, 1434738484);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_monitor_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_monitor_table` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `bug_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`bug_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_relationship_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_relationship_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source_bug_id` int(10) unsigned NOT NULL DEFAULT '0',
  `destination_bug_id` int(10) unsigned NOT NULL DEFAULT '0',
  `relationship_type` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_relationship_source` (`source_bug_id`),
  KEY `idx_relationship_destination` (`destination_bug_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_revision_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_revision_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bug_id` int(10) unsigned NOT NULL,
  `bugnote_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `value` longtext NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_bug_rev_type` (`type`),
  KEY `idx_bug_rev_id_time` (`bug_id`,`timestamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mantis_bug_revision_table`
--

INSERT INTO `mantis_bug_revision_table` (`id`, `bug_id`, `bugnote_id`, `user_id`, `type`, `value`, `timestamp`) VALUES
(1, 38, 0, 5, 3, '', 1433270555),
(2, 38, 0, 1, 3, 'Se genera un cambio de Ram ampliadola de 4 gb a 6 gb , con lo que la computadora al generar pruebas nuevamente responde de forma adecuada permitiendo que el usuario pueda trabajar sin problemas', 1433271034),
(3, 37, 0, 4, 3, '', 1433270415),
(4, 37, 0, 1, 3, 'Se instala el corrector ortografico y se cambia el lenguaje de teclado para que detecte el lenguaje establecido', 1433271300);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reporter_id` int(10) unsigned NOT NULL DEFAULT '0',
  `handler_id` int(10) unsigned NOT NULL DEFAULT '0',
  `duplicate_id` int(10) unsigned NOT NULL DEFAULT '0',
  `priority` smallint(6) NOT NULL DEFAULT '30',
  `severity` smallint(6) NOT NULL DEFAULT '50',
  `reproducibility` smallint(6) NOT NULL DEFAULT '10',
  `status` smallint(6) NOT NULL DEFAULT '10',
  `resolution` smallint(6) NOT NULL DEFAULT '10',
  `projection` smallint(6) NOT NULL DEFAULT '10',
  `eta` smallint(6) NOT NULL DEFAULT '10',
  `bug_text_id` int(10) unsigned NOT NULL DEFAULT '0',
  `os` varchar(32) NOT NULL DEFAULT '',
  `os_build` varchar(32) NOT NULL DEFAULT '',
  `platform` varchar(32) NOT NULL DEFAULT '',
  `version` varchar(64) NOT NULL DEFAULT '',
  `fixed_in_version` varchar(64) NOT NULL DEFAULT '',
  `build` varchar(32) NOT NULL DEFAULT '',
  `profile_id` int(10) unsigned NOT NULL DEFAULT '0',
  `view_state` smallint(6) NOT NULL DEFAULT '10',
  `summary` varchar(128) NOT NULL DEFAULT '',
  `sponsorship_total` int(11) NOT NULL DEFAULT '0',
  `sticky` tinyint(4) NOT NULL DEFAULT '0',
  `target_version` varchar(64) NOT NULL DEFAULT '',
  `category_id` int(10) unsigned NOT NULL DEFAULT '1',
  `date_submitted` int(10) unsigned NOT NULL DEFAULT '1',
  `due_date` int(10) unsigned NOT NULL DEFAULT '1',
  `last_updated` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_bug_sponsorship_total` (`sponsorship_total`),
  KEY `idx_bug_fixed_in_version` (`fixed_in_version`),
  KEY `idx_bug_status` (`status`),
  KEY `idx_project` (`project_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `mantis_bug_table`
--

INSERT INTO `mantis_bug_table` (`id`, `project_id`, `reporter_id`, `handler_id`, `duplicate_id`, `priority`, `severity`, `reproducibility`, `status`, `resolution`, `projection`, `eta`, `bug_text_id`, `os`, `os_build`, `platform`, `version`, `fixed_in_version`, `build`, `profile_id`, `view_state`, `summary`, `sponsorship_total`, `sticky`, `target_version`, `category_id`, `date_submitted`, `due_date`, `last_updated`) VALUES
(1, 1, 3, 1, 0, 40, 60, 10, 80, 20, 10, 10, 1, '', '', '', '', '', '', 0, 10, 'Problema de accesos a share point', 0, 0, '', 2, 1426617169, 1, 1426699289),
(2, 1, 3, 1, 0, 30, 50, 70, 90, 10, 10, 10, 2, '', '', '', '', '', '', 0, 10, 'Problema con Teclado', 0, 0, '', 2, 1426703619, 1, 1426782749),
(3, 1, 3, 1, 0, 40, 30, 10, 80, 20, 10, 10, 3, '', '', '', '', '', '', 0, 10, 'Configuración de impresora', 0, 0, '', 2, 1426695739, 1, 1426782549),
(4, 1, 3, 1, 0, 30, 20, 30, 80, 20, 10, 10, 4, '', '', '', '', '', '', 0, 10, 'Problema de conexion', 0, 0, '', 2, 1426796879, 1, 1426871479),
(5, 1, 3, 1, 0, 40, 10, 100, 80, 20, 10, 10, 5, '', '', '', '', '', '', 0, 10, 'Configuración de VPN', 0, 0, '', 2, 1426799839, 1, 1426869965),
(6, 1, 3, 1, 0, 30, 50, 90, 80, 20, 10, 10, 6, '', '', '', '', '', '', 0, 10, 'Problema de red', 0, 0, '', 2, 1427131385, 1, 1427214211),
(7, 1, 3, 1, 0, 60, 80, 10, 80, 20, 10, 10, 7, '', '', '', '', '', '', 0, 10, 'Falla en maquina', 0, 0, '', 2, 1427141631, 1, 1427216015),
(8, 1, 3, 1, 0, 40, 80, 10, 80, 20, 10, 10, 8, '', '', '', '', '', '', 0, 10, 'Reparacion de SO', 0, 0, '', 2, 1427153011, 1, 1427219705),
(9, 1, 3, 1, 0, 20, 10, 10, 80, 20, 10, 10, 9, '', '', '', '', '', '', 0, 10, 'Problema al ingresar al SAT por chrome', 0, 0, '', 2, 1427213105, 1, 1427236865),
(10, 1, 3, 1, 0, 30, 10, 10, 80, 20, 10, 10, 10, '', '', '', '', '', '', 0, 10, 'Problema share Point', 0, 0, '', 2, 1427223085, 1, 1427239862),
(11, 1, 3, 1, 0, 30, 10, 10, 80, 20, 10, 10, 11, '', '', '', '', '', '', 0, 10, 'Instalacion de VPN y revision Antivirus', 0, 0, '', 2, 1427230885, 1, 1427299262),
(12, 1, 3, 1, 0, 20, 20, 10, 80, 20, 10, 10, 12, '', '', '', '', '', '', 0, 10, 'equipo con fallas', 0, 0, '', 2, 1427404322, 1, 1427413942),
(13, 1, 3, 1, 0, 20, 20, 10, 90, 10, 10, 10, 13, '', '', '', '', '', '', 0, 10, 'equipo con fallas', 0, 0, '', 2, 1427475072, 1, 1427493676),
(14, 1, 3, 1, 0, 30, 50, 100, 80, 20, 10, 10, 14, '', '', '', '', '', '', 0, 10, 'Configurar host de maquina', 0, 0, '', 2, 1427825476, 1, 1427843711),
(15, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 15, '', '', '', '', '', '', 0, 10, 'configuración de host', 0, 0, '', 2, 1427911994, 1, 1427932575),
(16, 1, 3, 1, 0, 30, 50, 100, 80, 20, 10, 10, 16, '', '', '', '', '', '', 0, 10, 'configuración de maquina', 0, 0, '', 2, 1427922961, 1, 1427993176),
(17, 1, 3, 1, 0, 50, 80, 10, 80, 20, 10, 10, 17, '', '', '', '', '', '', 0, 10, 'problema en correo outlook', 0, 0, '', 2, 1428422774, 1, 1428446584),
(18, 1, 3, 1, 0, 40, 60, 10, 80, 20, 10, 10, 18, '', '', '', '', '', '', 0, 10, 'Conexión incorrecta', 0, 0, '', 2, 1428609821, 1, 1428690741),
(19, 1, 3, 1, 0, 10, 10, 100, 80, 20, 10, 10, 19, '', '', '', '', '', '', 0, 10, 'Instalacion de software en equipo', 0, 0, '', 2, 1428616946, 1, 1428695766),
(20, 1, 3, 1, 0, 60, 80, 10, 90, 10, 10, 10, 20, '', '', '', '', '', '', 0, 10, 'Problema ordenador', 0, 0, '', 2, 1429031194, 1, 1429048564),
(21, 1, 3, 1, 0, 30, 60, 10, 80, 20, 10, 10, 21, '', '', '', '', '', '', 0, 10, 'Problema de correo', 0, 0, '', 2, 1429200401, 1, 1429213561),
(22, 1, 3, 1, 0, 10, 50, 100, 80, 20, 10, 10, 22, '', '', '', '', '', '', 0, 10, 'Instalacion de software en equipo', 0, 0, '', 2, 1429298770, 1, 1429564621),
(23, 1, 3, 1, 0, 10, 50, 100, 80, 20, 10, 10, 23, '', '', '', '', '', '', 0, 10, 'Instalacion de software en equipo', 0, 0, '', 2, 1429632811, 1, 1429654411),
(24, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 24, '', '', '', '', '', '', 0, 10, 'Problema impresora', 0, 0, '', 2, 1429895581, 1, 1430161444),
(25, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 25, '', '', '', '', '', '', 0, 10, 'Reinstalacion de software', 0, 0, '', 2, 1430413496, 1, 1430430244),
(26, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 26, '', '', '', '', '', '', 0, 10, 'Configuración de impresora', 0, 0, '', 2, 1420483404, 1, 1420502267),
(27, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 27, '', '', '', '', '', '', 0, 10, 'Conexion Dispositivo movil', 0, 0, '', 2, 1420487757, 1, 1428254105),
(28, 1, 4, 1, 0, 50, 60, 70, 80, 20, 10, 10, 28, '', '', '', '', '', '', 0, 10, 'Adaptacion de oficina', 0, 0, '', 2, 1428264112, 1, 1430845462),
(29, 1, 4, 1, 0, 30, 50, 10, 80, 20, 10, 10, 29, '', '', '', '', '', '', 0, 10, 'Problema de conexion', 0, 0, '', 2, 1428272042, 1, 1430853842),
(30, 1, 4, 1, 0, 20, 10, 10, 80, 20, 10, 10, 30, '', '', '', '', '', '', 0, 10, 'Problema antivirus', 0, 0, '', 2, 1431014652, 1, 1431033862),
(31, 1, 4, 1, 0, 40, 60, 10, 80, 20, 10, 10, 31, '', '', '', '', '', '', 0, 10, 'Problema al abrio poryect', 0, 0, '', 2, 1431363792, 1, 1431382147),
(32, 1, 4, 1, 0, 10, 10, 70, 80, 20, 10, 10, 32, '', '', '', '', '', '', 0, 10, 'problema bateria', 0, 0, '', 2, 1431373384, 1, 1431539377),
(33, 1, 4, 1, 0, 30, 50, 90, 80, 20, 10, 10, 33, '', '', '', '', '', '', 0, 10, 'Problema red y bateria', 0, 0, '', 2, 1431378234, 1, 1431447067),
(34, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 34, '', '', '', '', '', '', 0, 10, 'Problema con conexion y office', 0, 0, '', 2, 1431453687, 1, 1431462087),
(35, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 35, '', '', '', '', '', '', 0, 10, 'Problema teclado', 0, 0, '', 2, 1431632484, 1, 1431637014),
(36, 1, 4, 1, 0, 30, 50, 70, 80, 20, 10, 10, 36, '', '', '', '', '', '', 0, 10, 'Problema office', 0, 0, '', 2, 1432056203, 1, 1432066803),
(37, 1, 4, 1, 0, 30, 50, 10, 80, 20, 10, 10, 37, '', '', '', '', '', '', 0, 10, 'Problema office', 0, 0, '', 2, 1432308323, 1, 1432578165),
(38, 1, 5, 1, 0, 40, 60, 10, 90, 10, 10, 10, 38, '', '', '', '', '', '', 0, 10, 'Problema en reaccion', 0, 0, '', 2, 1432331543, 1, 1432670435),
(39, 1, 6, 1, 0, 30, 50, 70, 90, 10, 10, 10, 39, '', '', '', '', '', '', 0, 10, 'Calentamiento de equipo', 0, 0, '', 2, 1432747422, 1, 1432953240),
(40, 1, 3, 1, 0, 30, 50, 30, 80, 20, 10, 10, 40, '', '', '', '', '', '', 0, 10, 'ruido en ventilador', 0, 0, '', 2, 1432929894, 1, 1433178743),
(41, 1, 3, 1, 0, 20, 50, 10, 80, 20, 10, 10, 41, '', '', '', '', '', '', 0, 10, 'Problema cable de red', 0, 0, '', 2, 1433195704, 1, 1433259956),
(42, 1, 3, 1, 0, 10, 10, 100, 80, 20, 10, 10, 42, '', '', '', '', '', '', 0, 10, 'requerimiento de cable de red', 0, 0, '', 2, 1433261046, 1, 1433282217),
(43, 1, 3, 1, 0, 30, 50, 30, 80, 20, 10, 10, 43, '', '', '', '', '', '', 0, 10, 'Problema de acceso VPN', 0, 0, '', 2, 1433178720, 1, 1433277120),
(44, 1, 3, 1, 0, 60, 50, 10, 80, 20, 10, 10, 44, '', '', '', '', '', '', 0, 10, 'Problema de conexion', 0, 0, '', 2, 1433344440, 1, 1433352780),
(45, 1, 3, 1, 0, 30, 50, 10, 80, 20, 10, 10, 45, '', '', '', '', '', '', 0, 10, 'Acceso carpeta respaldo', 0, 0, '', 2, 1433882160, 1, 1433883540),
(46, 1, 3, 1, 0, 20, 10, 90, 80, 20, 10, 10, 46, '', '', '', '', '', '', 0, 10, 'Conexion por cable ethernet', 0, 0, '', 2, 1433969040, 1, 1434049320),
(47, 1, 3, 7, 0, 20, 10, 10, 80, 20, 10, 10, 47, '', '', '', '', '', '', 0, 10, 'Configuracion de correo', 0, 0, '', 2, 1434046380, 1, 1434125460),
(48, 1, 3, 7, 0, 20, 10, 90, 80, 20, 10, 10, 48, '', '', '', '', '', '', 0, 10, 'Configuracion de correo', 0, 0, '', 2, 1434212700, 1, 1434230340),
(49, 1, 3, 1, 0, 20, 10, 90, 80, 20, 10, 10, 49, '', '', '', '', '', '', 0, 10, ' FALLA EN SCANNER', 0, 0, '', 2, 1434058500, 1, 1434125700),
(50, 1, 4, 1, 0, 30, 10, 10, 80, 20, 10, 10, 50, '', '', '', '', '', '', 0, 10, 'Problema de conexion', 0, 0, '', 2, 1434468101, 1, 1434479670),
(51, 1, 3, 7, 0, 20, 10, 50, 80, 20, 10, 10, 51, '', '', '', '', '', '', 0, 10, 'Falla conexion en internet wifi ,', 0, 0, '', 2, 1434563791, 1, 1434568194),
(52, 1, 3, 7, 0, 20, 10, 10, 80, 20, 10, 10, 52, '', '', '', '', '', '', 0, 10, 'Mause Bloquead', 0, 0, '', 2, 1434641346, 1, 1434642650),
(53, 1, 3, 1, 0, 40, 70, 90, 50, 10, 10, 10, 53, '', '', '', '', '', '', 0, 10, 'Camputadora Da;ana', 0, 0, '', 2, 1434641429, 1, 1434729380),
(54, 1, 4, 1, 0, 30, 10, 50, 80, 20, 10, 10, 54, '', '', '', '', '', '', 0, 10, 'Maquina acer escribe numeros en lugar de letras', 0, 0, '', 2, 1434642556, 1, 1434644907),
(55, 1, 3, 1, 0, 20, 50, 50, 80, 20, 10, 10, 55, '', '', '', '', '', '', 0, 10, 'Virus informaticos', 0, 0, '', 2, 1434645311, 1, 1434645834),
(56, 1, 3, 1, 0, 20, 20, 90, 80, 20, 10, 10, 56, '', '', '', '', '', '', 0, 10, 'Conexion impresora por cable', 0, 0, '', 2, 1434730633, 1, 1434738485);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_tag_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_tag_table` (
  `bug_id` int(10) unsigned NOT NULL DEFAULT '0',
  `tag_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `date_attached` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`bug_id`,`tag_id`),
  KEY `idx_bug_tag_tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_bug_text_table`
--

CREATE TABLE IF NOT EXISTS `mantis_bug_text_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  `steps_to_reproduce` longtext NOT NULL,
  `additional_information` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `mantis_bug_text_table`
--

INSERT INTO `mantis_bug_text_table` (`id`, `description`, `steps_to_reproduce`, `additional_information`) VALUES
(1, 'No es posible ingresar al sistema para obtener archivos de trabajo.', '', ''),
(2, 'Se me presenta un problema al momento de usar el teclado en mi maquina, este no funciona adecuadamente y deja de funcionar  de pronto, solicito asistencia para la solución del mismo', '', ''),
(3, 'Mi computadora no puede imprimir unos documentos que requiero, favor de solucionar problema entre mi equipo y la impresora, gracias', '', ''),
(4, 'Se presenta intermitencia en la conexión a Internet en mi maquina , favor de solucionar el problema de la mala conexión ', '', ''),
(5, 'SE requiere la instalación de una VPN en la maquina para poder tener acceso a las carpetas de la empresa desde fuera', '', ''),
(6, 'La conexión con QTP02 muestra problemas y complicaciones de acceso , requiero apoyo para solucionar dicho problema.', '', ''),
(7, 'El sistema operativo de la maquina es inaccesible , presenta problemas de uso , se solicita generar reparacion de equipo', '', ''),
(8, 'Maquina HP presenta problemas en Sistema operativo , se solicita la re instalacion del mismo con herramientas necesarias para generar el trabajo normal', '', ''),
(9, 'AL ingresar al SAT por chrome me genera problemas cosa que no me aparece si ingreso desde otro navegador', '', ''),
(10, 'NO puedo editar ningún documento dentro de Share point', '', ''),
(11, 'SE necesita que se instale VPN en mi maquina para laborar desde fuera y a su vez revisar mi antivirus ya que me marca error en cada momento', '', ''),
(12, 'El equipo presenta fallas en varias partes en diversos momentos , presenta falla con USB , conexion , Outlook lento , maquina se traba, se recomienda realizar revisión completa de todo el equipo ', '', ''),
(13, 'El equipo presenta fallas en varias partes en diversos momentos , presenta falla con USB , conexion , Outlook lento , maquina se traba, se recomienda realizar revisión completa de todo el equipo ', '', ''),
(14, 'Se requiere configuración de host en herramientas de trabajo para mayor fluidez en el acceso de las mismas', '', ''),
(15, 'Se requiere configurar host de herramientas de trabajo para mayor acceso al sistema', '', ''),
(16, 'se requiere aplicar check list de soporte en maquina para evitar perdida de información ', '', ''),
(17, 'La maquina presenta problemas de recepcion y envio de correo marca error 587 de conexion', '', ''),
(18, 'La conexion de la red es muy inestable y me desconecta muy seguido', '', ''),
(19, 'Se requiere la instalacion de todos los programas necesarios para laborar normalmente , proyect , visio , office , antivirus', '', ''),
(20, 'El problema se presenta debido a que la maquina al encender no puede arrancar adecuadamente , aparece pantalla azul , dispositivos no reconocidos', '', ''),
(21, 'Hola , necesito ayuda con mi correo no puedo recibirlos , solo envio , al momonto en que presiono el boton enviar y recibir dura demasiado y no recibo datos algunos', '', ''),
(22, 'se nesecita que se configure la maquina con todos los servicios para uso de trabajo dentro de ello nesecita la confuguracion de una cuenta de correo, office, project y visio', '', ''),
(23, 'nesecito que configuren una maquina con los siguientes programas una cuenta de correo, office, proyect, visio', '', ''),
(24, 'la impresora presenta error al realizar escaners , solo genera un sonido pero no escanea', '', ''),
(25, 'Se solicita actualizar driver de maquina y software del mismo ya que no puede correr ciertas aplicaciones para laborar normalmente', '', ''),
(26, 'Tengo problemas con la impresora , todo queda en cola de espera pero no imprime nada en absoluto\r\n', '', ''),
(27, 'Se solicita conectar un dispositivo movil por internet\r\n', '', ''),
(28, 'Es necesario adaptar la oficina de trabajo , se requiere que tenga un enlace de internet y telefonia IP\r\n', '', ''),
(29, 'La conexión por wifi presenta problemas solo se queda trabado y no puedo acceder a ella', '', ''),
(30, 'No puedo actualizar antivirus en mi ordenador marca error en cualquier momento', '', ''),
(31, 'No me es posible visualizar los trabajos de proyect por lo que se requiere la instalacion del programa para continuar con labores normales', '', ''),
(32, 'Muestra un mensaje sobre que la batería esta en mal estado , seria bueno revisar si esta  bien o en su defecto solicitar el cambio de la misma', '', ''),
(33, 'El equipo en ocasiones desconecta de la red , la bateria ya no funciona', '', ''),
(34, 'Se presenta porblemas de licencia office y no puedo acceder a redes qualtop', '', ''),
(35, 'Se presenta un problema con el uso de las fechas hacia arriba y hacia abajo, no siempres irven', '', ''),
(36, 'Al ingresar a office marca error de licencia por lo que empieza a limitar el funcionamiento del software', '', ''),
(37, 'Problema con el auto corrector ya que no funciona en mi maquina y no puedo comprobar faltas ortográficas en mis archivos', '', 'Se instala el corrector ortografico y se cambia el lenguaje de teclado para que detecte el lenguaje establecido'),
(38, 'La maquina esta demasiado lenta me es casi imposible generar mi trabajo normal ', '', 'Se genera un cambio de Ram ampliadola de 4 gb a 6 gb , con lo que la computadora al generar pruebas nuevamente responde de forma adecuada permitiendo que el usuario pueda trabajar sin problemas'),
(39, 'Se presenta problema con el equipo ya que se calienta mucho y empieza a ponerse lento ,a su vez el acceso al share point es bueno pero me pide doble password', '', ''),
(40, 'la maquina genera ruido en el ventilador como si tuviera basura, se solicita revision', '', ''),
(41, 'El cable de red muestra problemas se desconecta y reconecta favor de reparar el inconveniente', '', ''),
(42, 'Se solicita un cable de red para la generacion de un traspaso de archivos', '', ''),
(43, 'Se me presenta un problema al ingresar a la VPN por medio de mozilla ', '', ''),
(44, 'Mi maquina no puede conectarse a la red de qtp con salida a internet', '', ''),
(45, 'Al ingresar a mi carpeta de respaldos me marca un error pide usuario y password pero me niega el acceso', '', ''),
(46, 'se requiere adaptacion de cable para conexion a internet desde un lugar donde no tiene conexion', '', ''),
(47, 'Se require reubicar el correo electronico de usuario para que este sea respaldado', '', ''),
(48, 'Se require reubicar el correo electronico de usuario para que este sea respaldado', '', ''),
(49, 'el scanner que tiene mi impresora no funciona en mi ordenador , requiero apoyo para solucionar el problema que se me esta presentando', '', ''),
(50, 'Falla la conexion de manera continua y no puedo conectarme a ninguna red', '', ''),
(51, 'La conexion a internet en momentos se recibe y en otros deja de recibir conexion', '', ''),
(52, 'No se puede mover y usar los botones de raton', '', ''),
(53, 'Se requiere rescatar la informacion de un disco duro que pertenecia a una computadora danada', '', ''),
(54, 'La maquina en ciertas ocasiones , despues de trabajar se bloquea y comienza a escribir numeros en ligar de letras, se solicita ayuda para soluicionar dichjo problema', '', ''),
(55, 'En ciertos momentos aparecen mensajes de alerta de virus en la maquina ', '', ''),
(56, 'se requiere la conexion por cable para generar impresiones mucho mas rapidas que por red', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `mantis_category_table`
--

CREATE TABLE IF NOT EXISTS `mantis_category_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL DEFAULT '',
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_category_project_name` (`project_id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mantis_category_table`
--

INSERT INTO `mantis_category_table` (`id`, `project_id`, `user_id`, `name`, `status`) VALUES
(1, 0, 0, 'General', 0),
(2, 0, 1, 'Help Desk', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_config_table`
--

CREATE TABLE IF NOT EXISTS `mantis_config_table` (
  `config_id` varchar(64) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `access_reqd` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '90',
  `value` longtext NOT NULL,
  PRIMARY KEY (`config_id`,`project_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mantis_config_table`
--

INSERT INTO `mantis_config_table` (`config_id`, `project_id`, `user_id`, `access_reqd`, `type`, `value`) VALUES
('database_version', 0, 0, 90, 1, '183'),
('csv_columns', 0, 0, 90, 3, 'a:19:{i:0;s:2:"id";i:1;s:10:"project_id";i:2;s:11:"reporter_id";i:3;s:10:"handler_id";i:4;s:8:"priority";i:5;s:8:"severity";i:6;s:15:"reproducibility";i:7;s:7:"version";i:8;s:11:"category_id";i:9;s:14:"date_submitted";i:10;s:2:"os";i:11;s:8:"os_build";i:12;s:8:"platform";i:13;s:10:"view_state";i:14;s:12:"last_updated";i:15;s:7:"summary";i:16;s:6:"status";i:17;s:10:"resolution";i:18;s:16:"fixed_in_version";}'),
('excel_columns', 0, 0, 90, 3, 'a:22:{i:0;s:2:"id";i:1;s:10:"project_id";i:2;s:11:"reporter_id";i:3;s:10:"handler_id";i:4;s:8:"priority";i:5;s:8:"severity";i:6;s:15:"reproducibility";i:7;s:7:"version";i:8;s:11:"category_id";i:9;s:14:"date_submitted";i:10;s:2:"os";i:11;s:8:"os_build";i:12;s:8:"platform";i:13;s:10:"view_state";i:14;s:12:"last_updated";i:15;s:7:"summary";i:16;s:6:"status";i:17;s:10:"resolution";i:18;s:16:"fixed_in_version";i:19;s:26:"custom_correo electrónico";i:20;s:31:"custom_duración de resolución";i:21;s:13:"custom_poliza";}'),
('default_notify_flags', 1, 0, 90, 3, 'a:4:{s:8:"reporter";i:1;s:7:"handler";i:1;s:13:"threshold_min";i:100;s:13:"threshold_max";i:0;}'),
('notify_flags', 1, 0, 90, 3, 'a:11:{s:5:"owner";a:4:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;s:13:"threshold_min";s:2:"90";s:13:"threshold_max";s:2:"90";}s:8:"reopened";a:4:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;s:13:"threshold_min";s:2:"10";s:13:"threshold_max";s:2:"90";}s:7:"deleted";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}s:7:"bugnote";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}s:8:"relation";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}s:8:"feedback";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}s:12:"acknowledged";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}s:9:"confirmed";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}s:8:"assigned";a:4:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;s:13:"threshold_min";s:2:"10";s:13:"threshold_max";s:2:"90";}s:8:"resolved";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}s:6:"closed";a:2:{s:7:"monitor";i:1;s:8:"bugnotes";i:1;}}');

-- --------------------------------------------------------

--
-- Table structure for table `mantis_custom_field_project_table`
--

CREATE TABLE IF NOT EXISTS `mantis_custom_field_project_table` (
  `field_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sequence` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_id`,`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mantis_custom_field_project_table`
--

INSERT INTO `mantis_custom_field_project_table` (`field_id`, `project_id`, `sequence`) VALUES
(1, 1, 0),
(2, 1, 0),
(3, 1, 0),
(4, 1, 0),
(5, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_custom_field_string_table`
--

CREATE TABLE IF NOT EXISTS `mantis_custom_field_string_table` (
  `field_id` int(11) NOT NULL DEFAULT '0',
  `bug_id` int(11) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`bug_id`),
  KEY `idx_custom_field_bug` (`bug_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mantis_custom_field_string_table`
--

INSERT INTO `mantis_custom_field_string_table` (`field_id`, `bug_id`, `value`) VALUES
(3, 1, 'malvarado@qualtop.com'),
(2, 1, '300'),
(1, 1, '|No|'),
(3, 2, 'vmarquez@qualtop.com'),
(2, 2, '1560'),
(1, 2, '|No|'),
(3, 3, 'rpulido@qualtop.com'),
(2, 3, '1680'),
(1, 3, '|No|'),
(3, 4, 'asosa@qualtop.com'),
(2, 4, '180'),
(1, 4, '|No|'),
(3, 5, 'vmarquez@qualtop.com'),
(2, 5, '1320'),
(1, 5, '|No|'),
(3, 6, 'ghernandez@qualtop.com'),
(2, 6, '360'),
(1, 6, '|No|'),
(3, 7, 'ejurez@syesfotware.com'),
(2, 7, '5880'),
(1, 7, '|No|'),
(3, 8, 'fcovarrubias@qualtop.com'),
(2, 8, '5580'),
(1, 8, '|No|'),
(3, 9, 'bcalvillo@qualrop.com'),
(2, 9, '1500'),
(1, 9, '|No|'),
(3, 10, 'mgarcia@qualtop.com'),
(2, 10, '5700'),
(1, 10, '|No|'),
(3, 11, 'acruz@qualtop.com'),
(2, 11, '0'),
(1, 11, '|No|'),
(3, 12, 'ghernandez@qualtop.com'),
(2, 12, '7200'),
(1, 12, '|No|'),
(3, 13, 'ghernandez@qualtop.com'),
(2, 13, '5700'),
(1, 13, '|No|'),
(3, 14, 'acastro@qualtop.com'),
(2, 14, '600'),
(1, 14, '|No|'),
(3, 15, 'asanchez@qualtop.com'),
(2, 15, '600'),
(1, 15, '|No|'),
(3, 16, 'msoto@qualtop.com'),
(2, 16, '3900'),
(1, 16, '|No|'),
(3, 17, 'fcovarrubias@qualtop.com'),
(2, 17, '1440'),
(1, 17, '|No|'),
(3, 18, 'rvalle@qualtop.com'),
(2, 18, '3600'),
(1, 18, '|No|'),
(3, 19, 'msoto@qualtop.com'),
(2, 19, '3600'),
(1, 19, '|No|'),
(3, 20, 'hdelatorre@qualtop.com'),
(2, 20, '1500'),
(1, 20, '|No|'),
(3, 21, 'vmarquez@qualtop.com'),
(2, 21, '720'),
(1, 21, '|No|'),
(3, 22, 'msoto@qualtop.com'),
(2, 22, '3000'),
(1, 22, '|No|'),
(3, 23, 'msoto@qualtop.com'),
(2, 23, '120'),
(1, 23, '|No|'),
(3, 24, 'n/A'),
(2, 24, '265'),
(1, 24, '|No|'),
(3, 25, 'qualtop'),
(2, 25, '125'),
(1, 25, '|No|'),
(3, 26, 'rvalle@qualtop.com'),
(2, 26, '1260'),
(1, 26, '|No|'),
(3, 27, 'mguerrero@qualtop.com'),
(2, 27, '120'),
(1, 27, '|No|'),
(3, 28, 'Miriam'),
(2, 28, '3600'),
(1, 28, '|No|'),
(3, 29, 'nreyes@syesoftware.com'),
(2, 29, '1680'),
(1, 29, '|No|'),
(3, 30, 'mryesta@syesoftware.com'),
(2, 30, '540'),
(1, 30, '|No|'),
(3, 31, 'ejuarez@syesoftware.com'),
(2, 31, '1320'),
(1, 31, '|No|'),
(3, 32, 'nreyes@syesoftware.com'),
(2, 32, '900'),
(1, 32, '|No|'),
(3, 33, 'mryesta@syesoftware.com'),
(2, 33, '1850'),
(1, 33, '|No|'),
(3, 34, 'mguerrero@qualtop.com'),
(2, 34, '1500'),
(1, 34, '|No|'),
(3, 35, 'cnunez@syesoftware.com'),
(2, 35, '1200'),
(1, 35, '|No|'),
(3, 36, 'ejuarez@syesoftware.com'),
(2, 36, '300'),
(1, 36, '|No|'),
(3, 37, 'gramos@syesoftware.com'),
(2, 37, '1800'),
(1, 37, '|No|'),
(3, 38, 'HTBP'),
(2, 38, '3600'),
(1, 38, '|No|'),
(3, 39, 'jvaldez@cinovatec.com'),
(2, 39, '3600'),
(1, 39, '|Si|'),
(4, 35, 'Se actualiza controlador de teclado y se generan pruebas las cuales no presentario problemas'),
(4, 26, 'Se configura el puerto e ip de impresion para que llegue sin porblemas a la red de la impresora, se procesa la cola y todos los documentos son impresos adecuadamente'),
(4, 34, 'Se genera cambio de licencia y se activa nuevamente, a su vez se cambia el password que estaba en mal estado'),
(4, 33, 'Se actualiza controlador de red y se genera una peticion para la compra de una nueva bateria'),
(4, 32, 'Se analiza la bateria y se determina que esta en buen estado (para ello se dio uso de una herramienta de analisis)'),
(4, 31, 'Se instala proyecto y se activa para que tenga acceso a los documentos requeridos'),
(4, 30, 'El problema que se presenta a Mystie se debe a que dentro de la red de QTP02 no se puede actualizar antivirus , se sugiere cambiar de red para solucionar problema'),
(4, 29, 'Se actualiza controlador de tarjeta de red, se reinicia maquina y el wifi vuelve a conectar sin problemas '),
(4, 36, 'Se genera cambio de licencia y se activa nuevamente'),
(4, 37, 'Se instala el corrector ortografico y se cambia el lenguaje de teclado para que detecte el lenguaje establecido'),
(4, 19, 'Se instala el software requerido y a su vez se configura la cuenta de correo para que funcione adecuadamente'),
(4, 18, 'Se configura los drivers de red ethernet y lan para que evite porblemas de conexion , se realiza pruebas y funciona adecuadamente.'),
(4, 17, 'Se genera un cambio en el puerto de acceso SMTP y POP, se generan pruebas y el correo ya puede ser tanto enviado como recibido'),
(4, 28, 'Se modifica area de trabajo pasando un cable de red por el techo hasta la oficina , se configura telefono y deja acceso a la red.'),
(4, 27, 'Se configura el equipo para que tenga acceso a internet agregando la clave de sye01'),
(4, 25, 'Se genera el chek list retomando datos de la maquina , instalando office, team viewer, VPN , antivirus , visio y proyect.'),
(4, 24, 'Se genera una configuracion de la maquina para que esta reconozca el puerto de escaner de la impresora, se generan pruebas se escaneado y funcionan adecuadamente , sin embargo cada cierto tiempo se presentan problemas de escaner por falla en lamparas de i'),
(4, 23, 'Se instala el software requerido y a su vez se configura la cuenta de correo para que funcione adecuadamente'),
(4, 21, 'Se configura correo ya que tenia un puerto uncorrecto de entrada motivo por el cual solo podia enviar pero no recibir'),
(4, 22, 'Se instala el software requerido para que funcione adecuadamente'),
(4, 20, 'Se determina que la maquina de Harim esta en mal estado por lo que se genera una cambio de maquina y la otra maquina se envia a soporte para validar si hay manera de restaurarla (El disco duro ya no es capaz de arrancar , y la bios esta estropeada)'),
(4, 16, 'Se genera el chek list retomando datos de la maquina , instalando office, team viewer, VPN , antivirus , visio y proyect.'),
(4, 15, 'Se configuran los documentos host, network y lmhosts para agregar la resolucion de nombres a qtpsp2010'),
(4, 14, 'Se configuran los documentos host, network y lmhosts para agregar la resolucion de nombres a qtpsp2010'),
(4, 12, 'Se actualizan controladores del sistema en general y se solicita la adquisicion de un ventilador debido a que el equipo se encuentra expuesto a mucho calor el cual suele afectar la funcionalidad del equipo'),
(4, 11, '2100'),
(4, 10, 'Se instalan los plugins necesarios para que pueda tener el correcto acceso al sistema de share point , (Acces database engine , y .net version 4)'),
(4, 13, 'Se actualizan controladores del sistema en general y se solicita la adquisicion de un ventilador debido a que el equipo se encuentra expuesto a mucho calor el cual suele afectar la funcionalidad del equipo'),
(4, 9, 'Tras un analisis se determina que el problema es generado por problemas entre chrome y java , motivo por el cual se recomienda no usar este explorador hasta que las empresas den solucion a sus problemas'),
(4, 8, 'Se instala en la maquina el sistema operativo windows 7 profesional y se cargan componentes de trabajo'),
(4, 7, 'Se instala en la maquina el sistema operativo windows 7 profesional y se cargan componentes de trabajo'),
(4, 4, 'Se configura el password de la red ya que no era el correcto , con ello se obtiene internet nuevamente'),
(4, 1, 'Se configura maquina para que tenga acceso a la red adecuada ya que se encontraba fuera de la red que se requiere para ingresar al share point'),
(4, 2, 'Se actualiza computadora con driver de teclado correcto y se cambia al idioma correcto de teclado para que los simbolos funciones tambien de forma adecuada.'),
(4, 6, 'Se actualiza el estado del password  y de la red , a su vez se reinicia controlador y con ello se vuelve a tener acceso a internet'),
(4, 5, 'Se instala y configura fortissl para que se tenga acceso a la red de qualtop desde fuera, se valida con usuario y efectivamente cuenta con acceso a internet'),
(4, 3, 'Se busca impresoras dentro de la red , se agrega y se configura para que sea la impresora por defecto , a su vez se instala el controlador de la misma para evitar problemas futuros'),
(3, 40, 'msoto@qualtop.com'),
(2, 40, '5100'),
(1, 40, '|Si|'),
(4, 40, 'Se abre la maquina y se limpia el ventilador el cual tenia una masa anaranjada y dura q interrumpia el correcto uso del ventilador'),
(3, 41, 'rvalle@qualtop.com'),
(2, 41, '1920'),
(1, 41, '|Si|'),
(4, 41, 'se cambia el conector que se encontraba en mal estado, motivo por el cual se desconectaba y reconectaba seguidamente'),
(3, 42, 'ivilla@qualtop.com'),
(2, 42, '660'),
(1, 42, '|Si|'),
(4, 42, 'Se habilita un cable de red para que pueda ser utilizado'),
(3, 43, 'vmarquez@qualtop.com'),
(2, 43, '3890'),
(1, 43, '|Si|'),
(4, 43, 'Se determina que el problema se debe a una complicacion de mozilla , motivo por el cual se recomienda no usar mozilla hasta que se recupere el problema por parte del navegador ya que el erro esta en la programacion del navegador'),
(3, 44, 'asosa@qualtop.com'),
(2, 44, '300'),
(1, 44, '|Si|'),
(4, 44, 'Se genera un cambio en la conexion de la VPN para que se tenga acceso a las conexiones de qualtop'),
(3, 45, 'pgutierrez@qualtop.com'),
(2, 45, '900'),
(1, 45, '|Si|'),
(4, 45, 'Se modifica password y usuario para que este tenga acceso al sistema de red'),
(4, 39, 'Se solicita compra de ventilador y se solicita configuracion en share point a administrador de sistema'),
(3, 46, 'marreola@qualtop.com'),
(2, 46, '600'),
(5, 46, '1434146400'),
(1, 46, '|Si|'),
(4, 46, 'Se adapta un cable de red a la zona se;alado por el usuario , se conecta cable a computadora y se valida que funcione adecauadamente'),
(3, 47, 'hdelatorr@qualtop.come'),
(2, 47, '3720'),
(5, 47, '1434171600'),
(1, 47, '|Si|'),
(4, 47, 'se cambia archivo a nueva localizacion y se reconfigura la maquina para que esta pueda registrar correo en el archivo con nueva direccion'),
(3, 48, 'hdelatorre@qualtop.com'),
(2, 48, '3720'),
(5, 48, '1434171600'),
(1, 48, '|Si|'),
(4, 48, 'Se modifica la configuracion del programa outlook y a su vez se mueve el archivo a la nueva direccion solicitada'),
(3, 49, 'mramos@qualtop.com'),
(2, 49, '3780'),
(5, 49, '1434232800'),
(1, 49, '|Si|'),
(4, 49, 'Se configura la maquina con el driver para que esta lea adecuadamente el adaptador del scanner , se valida con usuario generando el primer scanner'),
(3, 50, 'nreyes@syesoftware.com'),
(2, 50, '2280'),
(5, 50, '1434578400'),
(1, 50, '|Si|'),
(4, 50, 'Se reconfigura la conexion de red en el adaptador inalambrico , sin embargo se suguiere generar una resintalacion de SO lo mas pronto posible'),
(5, 45, '1434060000'),
(3, 51, 'asosa@qualtop.com'),
(2, 51, '900'),
(5, 51, '1434690000'),
(1, 51, '|Si|'),
(4, 51, 'Se apaga y prende el controlador y se busca problemas de red con solucionador de windows'),
(3, 52, 'ghernandez@qualtop.com'),
(2, 52, '600'),
(5, 52, '1434862800'),
(1, 52, '|Si|'),
(4, 52, 'Se desconecta los mouse alambricos , se reconectan y se activa la combinacion de telcas fn + block desp'),
(3, 53, 'msoto@qualtop.com'),
(2, 53, '0'),
(5, 53, '1434690000'),
(1, 53, '|Si|'),
(4, 53, 'N/a'),
(3, 54, 'mramos@syesoftware.com'),
(2, 54, '240'),
(5, 54, '1434776400'),
(1, 54, '|Si|'),
(4, 54, 'Se configra la maquina y se explica a usuario q en caso de ocurrir presione fn + num block'),
(3, 55, 'asanchez@qualtop.com'),
(2, 55, '120'),
(5, 55, '1434862800'),
(1, 55, '|Si|'),
(4, 55, 'se pone en densifeccion y cuarentena los virus almacenados en el sistema'),
(3, 56, 'rpulido@qualtop.com'),
(2, 56, '960'),
(5, 56, '1434949200'),
(1, 56, '|Si|'),
(4, 56, 'se otorga un cable usb y se configura maquina para que tenga acceso a la impresora directamente');

-- --------------------------------------------------------

--
-- Table structure for table `mantis_custom_field_table`
--

CREATE TABLE IF NOT EXISTS `mantis_custom_field_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `type` smallint(6) NOT NULL DEFAULT '0',
  `possible_values` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  `valid_regexp` varchar(255) NOT NULL DEFAULT '',
  `access_level_r` smallint(6) NOT NULL DEFAULT '0',
  `access_level_rw` smallint(6) NOT NULL DEFAULT '0',
  `length_min` int(11) NOT NULL DEFAULT '0',
  `length_max` int(11) NOT NULL DEFAULT '0',
  `require_report` tinyint(4) NOT NULL DEFAULT '0',
  `require_update` tinyint(4) NOT NULL DEFAULT '0',
  `display_report` tinyint(4) NOT NULL DEFAULT '0',
  `display_update` tinyint(4) NOT NULL DEFAULT '1',
  `require_resolved` tinyint(4) NOT NULL DEFAULT '0',
  `display_resolved` tinyint(4) NOT NULL DEFAULT '0',
  `display_closed` tinyint(4) NOT NULL DEFAULT '0',
  `require_closed` tinyint(4) NOT NULL DEFAULT '0',
  `filter_by` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_custom_field_name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mantis_custom_field_table`
--

INSERT INTO `mantis_custom_field_table` (`id`, `name`, `type`, `possible_values`, `default_value`, `valid_regexp`, `access_level_r`, `access_level_rw`, `length_min`, `length_max`, `require_report`, `require_update`, `display_report`, `display_update`, `require_resolved`, `display_resolved`, `display_closed`, `require_closed`, `filter_by`) VALUES
(1, 'Poliza', 7, '|Si|No', 'No', '', 10, 10, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1),
(2, 'Duración de Resolución', 1, '', '0', '', 10, 10, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0),
(3, 'Correo electrónico', 0, '', '', '', 10, 10, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1),
(4, 'Solucion', 0, '', 'N/a', '', 10, 10, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1),
(5, 'Fecha de compromiso', 8, '', '', '', 10, 10, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_email_table`
--

CREATE TABLE IF NOT EXISTS `mantis_email_table` (
  `email_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(64) NOT NULL DEFAULT '',
  `subject` varchar(250) NOT NULL DEFAULT '',
  `metadata` longtext NOT NULL,
  `body` longtext NOT NULL,
  `submitted` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`email_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=151 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_filters_table`
--

CREATE TABLE IF NOT EXISTS `mantis_filters_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `is_public` tinyint(4) DEFAULT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `filter_string` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mantis_filters_table`
--

INSERT INTO `mantis_filters_table` (`id`, `user_id`, `project_id`, `is_public`, `name`, `filter_string`) VALUES
(1, 1, 0, 0, '', 'v8#a:43:{s:16:"_source_query_id";s:0:"";s:8:"_version";s:2:"v8";s:10:"_view_type";s:6:"simple";s:13:"show_category";a:1:{i:0;s:1:"0";}s:13:"show_severity";a:1:{i:0;i:0;}s:11:"show_status";a:1:{i:0;i:0;}s:8:"per_page";i:50;s:17:"highlight_changed";i:6;s:11:"reporter_id";a:1:{i:0;i:0;}s:10:"handler_id";a:1:{i:0;i:0;}s:10:"project_id";a:1:{i:0;i:-3;}s:4:"sort";s:12:"last_updated";s:3:"dir";s:4:"DESC";s:11:"start_month";i:6;s:9:"start_day";i:1;s:10:"start_year";i:2015;s:9:"end_month";i:6;s:7:"end_day";i:1;s:8:"end_year";i:2015;s:6:"search";s:0:"";s:11:"hide_status";a:1:{i:0;i:-2;}s:16:"and_not_assigned";b:0;s:15:"show_resolution";a:1:{i:0;i:0;}s:10:"show_build";a:1:{i:0;s:1:"0";}s:12:"show_version";a:1:{i:0;s:1:"0";}s:17:"do_filter_by_date";b:0;s:16:"fixed_in_version";a:1:{i:0;s:1:"0";}s:14:"target_version";a:1:{i:0;s:1:"0";}s:13:"show_priority";a:1:{i:0;i:0;}s:12:"user_monitor";a:1:{i:0;i:0;}s:10:"view_state";i:0;s:13:"custom_fields";a:0:{}s:13:"sticky_issues";s:3:"off";s:17:"relationship_type";i:-1;s:16:"relationship_bug";i:0;s:12:"show_profile";a:1:{i:0;i:0;}s:8:"platform";a:1:{i:0;s:1:"0";}s:2:"os";a:1:{i:0;s:1:"0";}s:8:"os_build";a:1:{i:0;s:1:"0";}s:10:"tag_string";s:0:"";s:10:"tag_select";i:0;s:12:"note_user_id";a:1:{i:0;i:0;}s:10:"match_type";i:0;}');

-- --------------------------------------------------------

--
-- Table structure for table `mantis_news_table`
--

CREATE TABLE IF NOT EXISTS `mantis_news_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `poster_id` int(10) unsigned NOT NULL DEFAULT '0',
  `view_state` smallint(6) NOT NULL DEFAULT '10',
  `announcement` tinyint(4) NOT NULL DEFAULT '0',
  `headline` varchar(64) NOT NULL DEFAULT '',
  `body` longtext NOT NULL,
  `last_modified` int(10) unsigned NOT NULL DEFAULT '1',
  `date_posted` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_plugin_table`
--

CREATE TABLE IF NOT EXISTS `mantis_plugin_table` (
  `basename` varchar(40) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '0',
  `protected` tinyint(4) NOT NULL DEFAULT '0',
  `priority` int(10) unsigned NOT NULL DEFAULT '3',
  PRIMARY KEY (`basename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mantis_plugin_table`
--

INSERT INTO `mantis_plugin_table` (`basename`, `enabled`, `protected`, `priority`) VALUES
('MantisCoreFormatting', 1, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_project_file_table`
--

CREATE TABLE IF NOT EXISTS `mantis_project_file_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `description` varchar(250) NOT NULL DEFAULT '',
  `diskfile` varchar(250) NOT NULL DEFAULT '',
  `filename` varchar(250) NOT NULL DEFAULT '',
  `folder` varchar(250) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `file_type` varchar(250) NOT NULL DEFAULT '',
  `content` longblob NOT NULL,
  `date_added` int(10) unsigned NOT NULL DEFAULT '1',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_project_hierarchy_table`
--

CREATE TABLE IF NOT EXISTS `mantis_project_hierarchy_table` (
  `child_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `inherit_parent` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx_project_hierarchy_child_id` (`child_id`),
  KEY `idx_project_hierarchy_parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_project_table`
--

CREATE TABLE IF NOT EXISTS `mantis_project_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `status` smallint(6) NOT NULL DEFAULT '10',
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  `view_state` smallint(6) NOT NULL DEFAULT '10',
  `access_min` smallint(6) NOT NULL DEFAULT '10',
  `file_path` varchar(250) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `category_id` int(10) unsigned NOT NULL DEFAULT '1',
  `inherit_global` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_project_name` (`name`),
  KEY `idx_project_view` (`view_state`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mantis_project_table`
--

INSERT INTO `mantis_project_table` (`id`, `name`, `status`, `enabled`, `view_state`, `access_min`, `file_path`, `description`, `category_id`, `inherit_global`) VALUES
(1, 'Help Desk', 50, 1, 10, 10, '', 'Sistema de Soporte VIA', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_project_user_list_table`
--

CREATE TABLE IF NOT EXISTS `mantis_project_user_list_table` (
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `access_level` smallint(6) NOT NULL DEFAULT '10',
  PRIMARY KEY (`project_id`,`user_id`),
  KEY `idx_project_user` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_project_version_table`
--

CREATE TABLE IF NOT EXISTS `mantis_project_version_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `version` varchar(64) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `released` tinyint(4) NOT NULL DEFAULT '1',
  `obsolete` tinyint(4) NOT NULL DEFAULT '0',
  `date_order` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_project_version` (`project_id`,`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_sponsorship_table`
--

CREATE TABLE IF NOT EXISTS `mantis_sponsorship_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bug_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL DEFAULT '0',
  `logo` varchar(128) NOT NULL DEFAULT '',
  `url` varchar(128) NOT NULL DEFAULT '',
  `paid` tinyint(4) NOT NULL DEFAULT '0',
  `date_submitted` int(10) unsigned NOT NULL DEFAULT '1',
  `last_updated` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_sponsorship_bug_id` (`bug_id`),
  KEY `idx_sponsorship_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_tag_table`
--

CREATE TABLE IF NOT EXISTS `mantis_tag_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `date_created` int(10) unsigned NOT NULL DEFAULT '1',
  `date_updated` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`name`),
  KEY `idx_tag_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_tokens_table`
--

CREATE TABLE IF NOT EXISTS `mantis_tokens_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `value` longtext NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '1',
  `expiry` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_typeowner` (`type`,`owner`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `mantis_tokens_table`
--

INSERT INTO `mantis_tokens_table` (`id`, `owner`, `type`, `value`, `timestamp`, `expiry`) VALUES
(5, 3, 5, 'a:1:{s:7:"profile";b:0;}', 1433178311, 1465876056),
(6, 1, 5, 'a:1:{s:7:"profile";b:0;}', 1433178341, 1464985852),
(8, 5, 5, 'a:1:{s:7:"profile";b:0;}', 1433178536, 1464806670),
(15, 4, 5, 'a:1:{s:7:"profile";b:0;}', 1433267775, 1464806469),
(41, 1, 3, '56,53,55,54,52', 1434479604, 1434825728),
(47, 3, 3, '56,55,53,52,51', 1434563791, 1434817033),
(61, 1, 4, '1', 1434739323, 1434739623);

-- --------------------------------------------------------

--
-- Table structure for table `mantis_user_pref_table`
--

CREATE TABLE IF NOT EXISTS `mantis_user_pref_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `project_id` int(10) unsigned NOT NULL DEFAULT '0',
  `default_profile` int(10) unsigned NOT NULL DEFAULT '0',
  `default_project` int(10) unsigned NOT NULL DEFAULT '0',
  `refresh_delay` int(11) NOT NULL DEFAULT '0',
  `redirect_delay` int(11) NOT NULL DEFAULT '0',
  `bugnote_order` varchar(4) NOT NULL DEFAULT 'ASC',
  `email_on_new` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_assigned` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_feedback` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_resolved` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_closed` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_reopened` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_bugnote` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_status` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_priority` tinyint(4) NOT NULL DEFAULT '0',
  `email_on_priority_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_status_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_bugnote_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_reopened_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_closed_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_resolved_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_feedback_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_assigned_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_on_new_min_severity` smallint(6) NOT NULL DEFAULT '10',
  `email_bugnote_limit` smallint(6) NOT NULL DEFAULT '0',
  `language` varchar(32) NOT NULL DEFAULT 'english',
  `timezone` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `mantis_user_pref_table`
--

INSERT INTO `mantis_user_pref_table` (`id`, `user_id`, `project_id`, `default_profile`, `default_project`, `refresh_delay`, `redirect_delay`, `bugnote_order`, `email_on_new`, `email_on_assigned`, `email_on_feedback`, `email_on_resolved`, `email_on_closed`, `email_on_reopened`, `email_on_bugnote`, `email_on_status`, `email_on_priority`, `email_on_priority_min_severity`, `email_on_status_min_severity`, `email_on_bugnote_min_severity`, `email_on_reopened_min_severity`, `email_on_closed_min_severity`, `email_on_resolved_min_severity`, `email_on_feedback_min_severity`, `email_on_assigned_min_severity`, `email_on_new_min_severity`, `email_bugnote_limit`, `language`, `timezone`) VALUES
(1, 1, 0, 0, 1, 30, 2, 'ASC', 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'spanish', 'America/Mexico_City'),
(2, 3, 0, 0, 1, 30, 2, 'ASC', 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'spanish', 'America/Mexico_City'),
(3, 5, 0, 0, 1, 30, 2, 'ASC', 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'english', 'Europe/Berlin'),
(4, 4, 0, 0, 1, 30, 2, 'ASC', 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'spanish', 'America/Mexico_City'),
(5, 6, 0, 0, 1, 30, 2, 'ASC', 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'english', 'Europe/Berlin'),
(6, 7, 0, 0, 1, 30, 2, 'ASC', 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'spanish', 'America/Mexico_City');

-- --------------------------------------------------------

--
-- Table structure for table `mantis_user_print_pref_table`
--

CREATE TABLE IF NOT EXISTS `mantis_user_print_pref_table` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `print_pref` varchar(64) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_user_profile_table`
--

CREATE TABLE IF NOT EXISTS `mantis_user_profile_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `platform` varchar(32) NOT NULL DEFAULT '',
  `os` varchar(32) NOT NULL DEFAULT '',
  `os_build` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mantis_user_table`
--

CREATE TABLE IF NOT EXISTS `mantis_user_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '',
  `realname` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  `protected` tinyint(4) NOT NULL DEFAULT '0',
  `access_level` smallint(6) NOT NULL DEFAULT '10',
  `login_count` int(11) NOT NULL DEFAULT '0',
  `lost_password_request_count` smallint(6) NOT NULL DEFAULT '0',
  `failed_login_count` smallint(6) NOT NULL DEFAULT '0',
  `cookie_string` varchar(64) NOT NULL DEFAULT '',
  `last_visit` int(10) unsigned NOT NULL DEFAULT '1',
  `date_created` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_cookie_string` (`cookie_string`),
  UNIQUE KEY `idx_user_username` (`username`),
  KEY `idx_enable` (`enabled`),
  KEY `idx_access` (`access_level`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `mantis_user_table`
--

INSERT INTO `mantis_user_table` (`id`, `username`, `realname`, `email`, `password`, `enabled`, `protected`, `access_level`, `login_count`, `lost_password_request_count`, `failed_login_count`, `cookie_string`, `last_visit`, `date_created`) VALUES
(1, 'helpdesk', 'Jovanny', 'zepedaroque@hotmail.com', '8e76d963ea82fca4b46c8edd92db09d7', 1, 0, 90, 29, 0, 0, '73e53a7a1975517b4fe9f226180d398a54010e2cfd7adf7b9033a2f2f2979b67', 1434739328, 1433135865),
(3, 'QTP', 'qualtop', 'msoto@qualtop.com', 'f1224851d5a99c0f095df877fbfc31b4', 1, 0, 25, 11, 0, 0, 'bbb759436ffdeec6b4a50b3a105d7e8fc2bda6ae5c55012a76ccc6d7e190838e', 1434730636, 1433176971),
(5, 'HTBP', 'HTBP', 'jovanny.zepedamercantil@corb.mx', '8e13c1db5586588388ffd22ff4f0f1f8', 1, 0, 25, 2, 0, 0, 'e5b9b600dfb78a60edc7483c5f15b070d88244a243940970fd74622f0e12abcd', 1433270658, 1433177722),
(4, 'SYE', 'SYE', 'sye@syesoftware.com', 'b52a8e76fc6f52d22b4d795aa6dbe3c3', 1, 0, 25, 4, 0, 0, '6c9b1c533f1739cb8b7e726370364aed53c5bd47884338d0f93af62aeb6d5d4f', 1434642560, 1433177015),
(6, 'CINOVATEC', 'CINOVATEC', 'compras@socialideas.mx', '37f49470a21d1b4d47df640973180707', 1, 0, 25, 1, 0, 0, '4901251b477a3c9b7833519ff19a9a8349539fa4c7df7d64a21453dde46d55c9', 1433270577, 1433177773),
(7, 'samuel', 'samuel', 'sami-gren94@hotmail.com', 'd8ae5776067290c4712fa454006c8ec6', 1, 0, 90, 4, 0, 0, '5c3c0d85f29863315dca97992d292c8cfc6b2dd9cd9597a348fa6e551d04478e', 1434642651, 1434339412);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
